import { pgTable, text, serial, integer, boolean, timestamp, foreignKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  role: text("role").notNull().default("student"), // "student" or "admin"
  active: boolean("active").notNull().default(true),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
  role: true,
});

// Books table
export const books = pgTable("books", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  author: text("author").notNull(),
  isbn: text("isbn").notNull().unique(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  coverImage: text("cover_image"),
  totalCopies: integer("total_copies").notNull().default(1),
  availableCopies: integer("available_copies").notNull().default(1),
});

export const insertBookSchema = createInsertSchema(books).pick({
  title: true,
  author: true,
  isbn: true,
  category: true,
  description: true,
  coverImage: true,
  totalCopies: true,
  availableCopies: true,
});

// Borrows table
export const borrows = pgTable("borrows", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  bookId: integer("book_id")
    .notNull()
    .references(() => books.id, { onDelete: "cascade" }),
  borrowDate: timestamp("borrow_date").notNull().defaultNow(),
  dueDate: timestamp("due_date").notNull(),
  returnDate: timestamp("return_date"),
  status: text("status").notNull().default("active"), // "active", "returned", "overdue"
});

export const insertBorrowSchema = createInsertSchema(borrows).pick({
  userId: true,
  bookId: true,
  dueDate: true,
});

// Reservations table
export const reservations = pgTable("reservations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  bookId: integer("book_id")
    .notNull()
    .references(() => books.id, { onDelete: "cascade" }),
  reservationDate: timestamp("reservation_date").notNull().defaultNow(),
  status: text("status").notNull().default("pending"), // "pending", "approved", "denied", "completed"
});

export const insertReservationSchema = createInsertSchema(reservations).pick({
  userId: true,
  bookId: true,
});

// Library Cards table
export const libraryCards = pgTable("library_cards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  cardNumber: text("card_number").notNull().unique(),
  issueDate: timestamp("issue_date").notNull().defaultNow(),
  expiryDate: timestamp("expiry_date").notNull(),
  status: text("status").notNull().default("active"), // "active", "expired", "suspended"
  address: text("address"),
  phone: text("phone"),
  emergencyContact: text("emergency_contact"),
});

export const insertLibraryCardSchema = createInsertSchema(libraryCards).pick({
  userId: true,
  cardNumber: true,
  expiryDate: true,
  address: true,
  phone: true,
  emergencyContact: true,
});

// Relations definitions
export const usersRelations = relations(users, ({ many, one }) => ({
  borrows: many(borrows),
  reservations: many(reservations),
  libraryCard: one(libraryCards),
}));

export const booksRelations = relations(books, ({ many }) => ({
  borrows: many(borrows),
  reservations: many(reservations),
}));

export const borrowsRelations = relations(borrows, ({ one }) => ({
  user: one(users, {
    fields: [borrows.userId],
    references: [users.id],
  }),
  book: one(books, {
    fields: [borrows.bookId],
    references: [books.id],
  }),
}));

export const reservationsRelations = relations(reservations, ({ one }) => ({
  user: one(users, {
    fields: [reservations.userId],
    references: [users.id],
  }),
  book: one(books, {
    fields: [reservations.bookId],
    references: [books.id],
  }),
}));

export const libraryCardsRelations = relations(libraryCards, ({ one }) => ({
  user: one(users, {
    fields: [libraryCards.userId],
    references: [users.id],
  }),
}));

// Types based on the schemas
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Book = typeof books.$inferSelect;
export type InsertBook = z.infer<typeof insertBookSchema>;

export type Borrow = typeof borrows.$inferSelect;
export type InsertBorrow = z.infer<typeof insertBorrowSchema>;

export type Reservation = typeof reservations.$inferSelect;
export type InsertReservation = z.infer<typeof insertReservationSchema>;

export type LibraryCard = typeof libraryCards.$inferSelect;
export type InsertLibraryCard = z.infer<typeof insertLibraryCardSchema>;
