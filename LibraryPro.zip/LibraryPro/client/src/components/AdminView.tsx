import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import AdminSidebar from "./AdminSidebar";
import AdminHeader from "./AdminHeader";
import { Search, Book, Users, Filter, Plus, Edit, Trash, Info, Send } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns";

export default function AdminView() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [sidebarVisible, setSidebarVisible] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All Categories");
  const [statusFilter, setStatusFilter] = useState("All Status");
  const [isAddBookDialogOpen, setIsAddBookDialogOpen] = useState(false);
  const [isAddUserDialogOpen, setIsAddUserDialogOpen] = useState(false);
  const [newBook, setNewBook] = useState({
    title: "",
    author: "",
    isbn: "",
    category: "Fiction",
    description: "",
    coverImage: "",
    totalCopies: 1,
    availableCopies: 1,
  });
  const [newUser, setNewUser] = useState({
    username: "",
    password: "",
    fullName: "",
    email: "",
    role: "student",
  });

  // Book queries and mutations
  const { data: booksData, isLoading: booksLoading } = useQuery({
    queryKey: ['/api/books', searchQuery, categoryFilter],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchQuery) params.append("search", searchQuery);
      if (categoryFilter !== "All Categories") params.append("category", categoryFilter);
      
      const url = `/api/books${params.toString() ? `?${params.toString()}` : ''}`;
      const res = await fetch(url, { credentials: "include" });
      
      if (!res.ok) throw new Error("Failed to fetch books");
      return res.json();
    },
  });

  const addBook = useMutation({
    mutationFn: async (bookData: any) => {
      const res = await apiRequest("POST", "/api/books", bookData);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Book added successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/books'] });
      setIsAddBookDialogOpen(false);
      setNewBook({
        title: "",
        author: "",
        isbn: "",
        category: "Fiction",
        description: "",
        coverImage: "",
        totalCopies: 1,
        availableCopies: 1,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add book",
        variant: "destructive",
      });
    },
  });

  const deleteBook = useMutation({
    mutationFn: async (bookId: number) => {
      const res = await apiRequest("DELETE", `/api/books/${bookId}`, {});
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Book deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/books'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete book",
        variant: "destructive",
      });
    },
  });

  // User queries and mutations
  const { data: usersData, isLoading: usersLoading } = useQuery({
    queryKey: ['/api/users'],
    queryFn: async () => {
      const res = await fetch('/api/users', { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch users");
      return res.json();
    },
  });

  const addUser = useMutation({
    mutationFn: async (userData: any) => {
      const res = await apiRequest("POST", "/api/auth/register", userData);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User added successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      setIsAddUserDialogOpen(false);
      setNewUser({
        username: "",
        password: "",
        fullName: "",
        email: "",
        role: "student",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add user",
        variant: "destructive",
      });
    },
  });

  const deleteUser = useMutation({
    mutationFn: async (userId: number) => {
      const res = await apiRequest("DELETE", `/api/users/${userId}`, {});
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete user",
        variant: "destructive",
      });
    },
  });

  // Borrow queries and mutations
  const { data: borrowsData, isLoading: borrowsLoading } = useQuery({
    queryKey: ['/api/borrows'],
    queryFn: async () => {
      const res = await fetch('/api/borrows', { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch borrows");
      return res.json();
    },
  });

  const returnBook = useMutation({
    mutationFn: async (borrowId: number) => {
      const res = await apiRequest("POST", `/api/borrows/${borrowId}/return`, {});
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Book marked as returned",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/borrows'] });
      queryClient.invalidateQueries({ queryKey: ['/api/books'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to return book",
        variant: "destructive",
      });
    },
  });

  // Reservation queries and mutations
  const { data: reservationsData, isLoading: reservationsLoading } = useQuery({
    queryKey: ['/api/reservations'],
    queryFn: async () => {
      const res = await fetch('/api/reservations', { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch reservations");
      return res.json();
    },
  });

  const updateReservation = useMutation({
    mutationFn: async ({ id, status }: { id: number, status: string }) => {
      const res = await apiRequest("PUT", `/api/reservations/${id}`, { status });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Reservation updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/reservations'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update reservation",
        variant: "destructive",
      });
    },
  });

  const handleSearchBooks = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/books'] });
  };

  const handleAddBook = () => {
    addBook.mutate(newBook);
  };

  const handleAddUser = () => {
    addUser.mutate(newUser);
  };

  const handleDeleteBook = (bookId: number) => {
    if (window.confirm("Are you sure you want to delete this book?")) {
      deleteBook.mutate(bookId);
    }
  };

  const handleDeleteUser = (userId: number) => {
    if (window.confirm("Are you sure you want to delete this user?")) {
      deleteUser.mutate(userId);
    }
  };

  const handleReturnBook = (borrowId: number) => {
    returnBook.mutate(borrowId);
  };

  const handleUpdateReservation = (id: number, status: string) => {
    updateReservation.mutate({ id, status });
  };

  const getOverdueBooks = () => {
    if (!borrowsData?.borrows) return [];
    
    const now = new Date();
    return borrowsData.borrows.filter((borrow: any) => {
      const dueDate = new Date(borrow.dueDate);
      return borrow.status === "active" && now > dueDate;
    });
  };

  const getBorrowStatusBadge = (status: string, dueDate: string) => {
    const now = new Date();
    const due = new Date(dueDate);

    if (status === "returned") {
      return <Badge className="neutral-badge">Returned</Badge>;
    } else if (now > due) {
      return <Badge className="error-badge">Overdue</Badge>;
    } else if (due.getTime() - now.getTime() < 7 * 24 * 60 * 60 * 1000) { // 7 days
      return <Badge className="warning-badge">Due Soon</Badge>;
    } else {
      return <Badge className="success-badge">Active</Badge>;
    }
  };

  const getReservationStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge className="info-badge">Pending</Badge>;
      case "approved":
        return <Badge className="success-badge">Approved</Badge>;
      case "denied":
        return <Badge className="error-badge">Denied</Badge>;
      case "completed":
        return <Badge className="neutral-badge">Completed</Badge>;
      default:
        return <Badge className="info-badge">Pending</Badge>;
    }
  };

  return (
    <div className="flex flex-col md:flex-row flex-grow">
      <AdminSidebar
        isVisible={sidebarVisible}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />
      
      <div className="flex-grow flex flex-col">
        <AdminHeader onMenuClick={() => setSidebarVisible(!sidebarVisible)} />
        
        {/* Dashboard Content */}
        {activeTab === "dashboard" && (
          <div className="p-6 flex-grow">
            <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-medium">Total Books</h3>
                    <Book className="text-primary" />
                  </div>
                  <p className="text-3xl font-bold">{booksData?.books?.length || 0}</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-medium">Active Users</h3>
                    <Users className="text-primary" />
                  </div>
                  <p className="text-3xl font-bold">{usersData?.users?.length || 0}</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-medium">Books Borrowed</h3>
                    <Book className="text-primary" />
                  </div>
                  <p className="text-3xl font-bold">
                    {borrowsData?.borrows?.filter((b: any) => b.status === "active").length || 0}
                  </p>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium mb-4">Recent Activity</h3>
                  <div className="space-y-4">
                    {borrowsLoading ? (
                      <div>Loading activity...</div>
                    ) : (
                      borrowsData?.borrows?.slice(0, 4).map((borrow: any) => (
                        <div key={borrow.id} className="flex items-start gap-4">
                          <div className="bg-primary bg-opacity-10 p-2 rounded-full">
                            {borrow.status === "returned" ? (
                              <Book className="text-primary" />
                            ) : (
                              <Book className="text-primary" />
                            )}
                          </div>
                          <div>
                            <p className="font-medium">
                              {borrow.status === "returned" ? "Book returned" : "Book borrowed"}
                            </p>
                            <p className="text-sm text-neutral-300">
                              User borrowed "{borrow.book?.title}"
                            </p>
                            <p className="text-xs text-neutral-300">
                              {format(new Date(borrow.borrowDate), 'MMM d, yyyy')}
                            </p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium mb-4">Overdue Books</h3>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-neutral-200">
                      <thead>
                        <tr>
                          <th className="px-4 py-2 text-left text-xs font-medium text-neutral-300 uppercase tracking-wider">Book</th>
                          <th className="px-4 py-2 text-left text-xs font-medium text-neutral-300 uppercase tracking-wider">Student</th>
                          <th className="px-4 py-2 text-left text-xs font-medium text-neutral-300 uppercase tracking-wider">Due Date</th>
                          <th className="px-4 py-2 text-left text-xs font-medium text-neutral-300 uppercase tracking-wider">Days</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-neutral-200">
                        {borrowsLoading ? (
                          <tr>
                            <td colSpan={4} className="text-center py-4">Loading overdue books...</td>
                          </tr>
                        ) : getOverdueBooks().length > 0 ? (
                          getOverdueBooks().map((borrow: any) => {
                            const dueDate = new Date(borrow.dueDate);
                            const now = new Date();
                            const daysOverdue = Math.floor((now.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));
                            
                            return (
                              <tr key={borrow.id}>
                                <td className="px-4 py-2 text-sm">{borrow.book?.title}</td>
                                <td className="px-4 py-2 text-sm">User ID: {borrow.userId}</td>
                                <td className="px-4 py-2 text-sm">
                                  {format(dueDate, 'MMM d, yyyy')}
                                </td>
                                <td className="px-4 py-2 text-sm text-error">{daysOverdue}</td>
                              </tr>
                            );
                          })
                        ) : (
                          <tr>
                            <td colSpan={4} className="text-center py-4">No overdue books</td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
        
        {/* Manage Books Content */}
        {activeTab === "books" && (
          <div className="p-6 flex-grow">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold">Manage Books</h1>
              <Dialog open={isAddBookDialogOpen} onOpenChange={setIsAddBookDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary text-white flex items-center">
                    <Plus className="mr-1 h-4 w-4" /> Add New Book
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New Book</DialogTitle>
                    <DialogDescription>Enter the details for the new book</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="title" className="text-right">Title</Label>
                      <Input
                        id="title"
                        value={newBook.title}
                        onChange={(e) => setNewBook({ ...newBook, title: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="author" className="text-right">Author</Label>
                      <Input
                        id="author"
                        value={newBook.author}
                        onChange={(e) => setNewBook({ ...newBook, author: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="isbn" className="text-right">ISBN</Label>
                      <Input
                        id="isbn"
                        value={newBook.isbn}
                        onChange={(e) => setNewBook({ ...newBook, isbn: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="category" className="text-right">Category</Label>
                      <Select
                        value={newBook.category}
                        onValueChange={(value) => setNewBook({ ...newBook, category: value })}
                      >
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Fiction">Fiction</SelectItem>
                          <SelectItem value="Non-Fiction">Non-Fiction</SelectItem>
                          <SelectItem value="Science Fiction">Science Fiction</SelectItem>
                          <SelectItem value="History">History</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="description" className="text-right">Description</Label>
                      <Textarea
                        id="description"
                        value={newBook.description}
                        onChange={(e) => setNewBook({ ...newBook, description: e.target.value })}
                        className="col-span-3"
                        rows={3}
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="coverImage" className="text-right">Cover URL</Label>
                      <Input
                        id="coverImage"
                        value={newBook.coverImage}
                        onChange={(e) => setNewBook({ ...newBook, coverImage: e.target.value })}
                        className="col-span-3"
                        placeholder="https://..."
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="totalCopies" className="text-right">Total Copies</Label>
                      <Input
                        id="totalCopies"
                        type="number"
                        value={newBook.totalCopies}
                        onChange={(e) => setNewBook({ ...newBook, totalCopies: parseInt(e.target.value) || 1 })}
                        className="col-span-3"
                        min="1"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="availableCopies" className="text-right">Available Copies</Label>
                      <Input
                        id="availableCopies"
                        type="number"
                        value={newBook.availableCopies}
                        onChange={(e) => setNewBook({ ...newBook, availableCopies: parseInt(e.target.value) || 1 })}
                        className="col-span-3"
                        min="0"
                        max={newBook.totalCopies}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button onClick={handleAddBook}>Add Book</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
            
            <Card className="mb-6">
              <CardContent className="p-4">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-grow">
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                        <Search className="text-neutral-300" />
                      </span>
                      <Input
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pl-10 pr-4 py-2"
                        placeholder="Search books..."
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Select
                      value={categoryFilter}
                      onValueChange={setCategoryFilter}
                    >
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="All Categories" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="All Categories">All Categories</SelectItem>
                        <SelectItem value="Fiction">Fiction</SelectItem>
                        <SelectItem value="Non-Fiction">Non-Fiction</SelectItem>
                        <SelectItem value="Science Fiction">Science Fiction</SelectItem>
                        <SelectItem value="History">History</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button onClick={handleSearchBooks}>
                      <Filter className="mr-2 h-4 w-4" /> Filter
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-neutral-200">
                  <thead className="bg-neutral-100">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Title</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Author</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">ISBN</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Category</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Copies</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Available</th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-neutral-400 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-neutral-200">
                    {booksLoading ? (
                      <tr>
                        <td colSpan={7} className="text-center py-4">Loading books...</td>
                      </tr>
                    ) : booksData?.books?.length > 0 ? (
                      booksData.books.map((book: any) => (
                        <tr key={book.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium">{book.title}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm">{book.author}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm">{book.isbn}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm">{book.category}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm">{book.totalCopies}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm">{book.availableCopies}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <Button variant="link" className="text-primary hover:text-blue-800 mr-3">
                              <Edit className="h-4 w-4 mr-1" /> Edit
                            </Button>
                            <Button
                              variant="link"
                              className="text-error hover:text-red-800"
                              onClick={() => handleDeleteBook(book.id)}
                            >
                              <Trash className="h-4 w-4 mr-1" /> Delete
                            </Button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={7} className="text-center py-4">No books found</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}
        
        {/* Manage Users Content */}
        {activeTab === "users" && (
          <div className="p-6 flex-grow">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold">Manage Users</h1>
              <Dialog open={isAddUserDialogOpen} onOpenChange={setIsAddUserDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary text-white flex items-center">
                    <Plus className="mr-1 h-4 w-4" /> Add New User
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New User</DialogTitle>
                    <DialogDescription>Enter the details for the new user</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="fullName" className="text-right">Full Name</Label>
                      <Input
                        id="fullName"
                        value={newUser.fullName}
                        onChange={(e) => setNewUser({ ...newUser, fullName: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="username" className="text-right">Username</Label>
                      <Input
                        id="username"
                        value={newUser.username}
                        onChange={(e) => setNewUser({ ...newUser, username: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="email" className="text-right">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={newUser.email}
                        onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="password" className="text-right">Password</Label>
                      <Input
                        id="password"
                        type="password"
                        value={newUser.password}
                        onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="role" className="text-right">Role</Label>
                      <Select
                        value={newUser.role}
                        onValueChange={(value) => setNewUser({ ...newUser, role: value })}
                      >
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select role" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="student">Student</SelectItem>
                          <SelectItem value="admin">Admin</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button onClick={handleAddUser}>Add User</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
            
            <Card className="mb-6">
              <CardContent className="p-4">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-grow">
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                        <Search className="text-neutral-300" />
                      </span>
                      <Input
                        className="w-full pl-10 pr-4 py-2"
                        placeholder="Search users..."
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Select defaultValue="All Roles">
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="All Roles" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="All Roles">All Roles</SelectItem>
                        <SelectItem value="Student">Student</SelectItem>
                        <SelectItem value="Admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button>
                      <Filter className="mr-2 h-4 w-4" /> Filter
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-neutral-200">
                  <thead className="bg-neutral-100">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Name</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Email</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Role</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Status</th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-neutral-400 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-neutral-200">
                    {usersLoading ? (
                      <tr>
                        <td colSpan={5} className="text-center py-4">Loading users...</td>
                      </tr>
                    ) : usersData?.users?.length > 0 ? (
                      usersData.users.map((user: any) => (
                        <tr key={user.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium">{user.fullName}</div>
                            <div className="text-sm text-neutral-300">@{user.username}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm">{user.email}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm capitalize">{user.role}</td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <Badge className="success-badge">Active</Badge>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <Button variant="link" className="text-primary hover:text-blue-800 mr-3">
                              <Edit className="h-4 w-4 mr-1" /> Edit
                            </Button>
                            <Button
                              variant="link"
                              className="text-error hover:text-red-800"
                              onClick={() => handleDeleteUser(user.id)}
                            >
                              <Trash className="h-4 w-4 mr-1" /> Delete
                            </Button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={5} className="text-center py-4">No users found</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}
        
        {/* Reservations Content */}
        {activeTab === "reservations" && (
          <div className="p-6 flex-grow">
            <h1 className="text-2xl font-bold mb-6">Manage Reservations</h1>
            
            <Card className="mb-6">
              <CardContent className="p-4">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-grow">
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                        <Search className="text-neutral-300" />
                      </span>
                      <Input
                        className="w-full pl-10 pr-4 py-2"
                        placeholder="Search by book or user..."
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Select
                      value={statusFilter}
                      onValueChange={setStatusFilter}
                    >
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="All Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="All Status">All Status</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="approved">Approved</SelectItem>
                        <SelectItem value="denied">Denied</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button>
                      <Filter className="mr-2 h-4 w-4" /> Filter
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-neutral-200">
                  <thead className="bg-neutral-100">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Book Title</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">User</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Date Requested</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Status</th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-neutral-400 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-neutral-200">
                    {reservationsLoading ? (
                      <tr>
                        <td colSpan={5} className="text-center py-4">Loading reservations...</td>
                      </tr>
                    ) : reservationsData?.reservations?.length > 0 ? (
                      reservationsData.reservations
                        .filter((reservation: any) => 
                          statusFilter === "All Status" || reservation.status === statusFilter
                        )
                        .map((reservation: any) => (
                          <tr key={reservation.id}>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-medium">{reservation.book?.title}</div>
                              <div className="text-sm text-neutral-300">{reservation.book?.author}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">User ID: {reservation.userId}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              {format(new Date(reservation.reservationDate), 'MMM d, yyyy')}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {getReservationStatusBadge(reservation.status)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                              {reservation.status === "pending" ? (
                                <>
                                  <Button
                                    variant="link"
                                    className="text-success hover:text-green-800 mr-3"
                                    onClick={() => handleUpdateReservation(reservation.id, "approved")}
                                  >
                                    Approve
                                  </Button>
                                  <Button
                                    variant="link"
                                    className="text-error hover:text-red-800"
                                    onClick={() => handleUpdateReservation(reservation.id, "denied")}
                                  >
                                    Deny
                                  </Button>
                                </>
                              ) : (
                                <Button variant="link" className="text-info hover:text-blue-800">
                                  <Info className="h-4 w-4 mr-1" /> View Details
                                </Button>
                              )}
                            </td>
                          </tr>
                        ))
                    ) : (
                      <tr>
                        <td colSpan={5} className="text-center py-4">No reservations found</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}
        
        {/* Borrowed Books Content */}
        {activeTab === "borrowed" && (
          <div className="p-6 flex-grow">
            <h1 className="text-2xl font-bold mb-6">Borrowed Books</h1>
            
            <Card className="mb-6">
              <CardContent className="p-4">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-grow">
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                        <Search className="text-neutral-300" />
                      </span>
                      <Input
                        className="w-full pl-10 pr-4 py-2"
                        placeholder="Search by book or user..."
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Select defaultValue="All Status">
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="All Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="All Status">All Status</SelectItem>
                        <SelectItem value="Active">Active</SelectItem>
                        <SelectItem value="Overdue">Overdue</SelectItem>
                        <SelectItem value="Returned">Returned</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button>
                      <Filter className="mr-2 h-4 w-4" /> Filter
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-neutral-200">
                  <thead className="bg-neutral-100">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Book Title</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Borrowed By</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Borrow Date</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Due Date</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Status</th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-neutral-400 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-neutral-200">
                    {borrowsLoading ? (
                      <tr>
                        <td colSpan={6} className="text-center py-4">Loading borrowed books...</td>
                      </tr>
                    ) : borrowsData?.borrows?.length > 0 ? (
                      borrowsData.borrows.map((borrow: any) => (
                        <tr key={borrow.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium">{borrow.book?.title}</div>
                            <div className="text-sm text-neutral-300">{borrow.book?.author}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm">User ID: {borrow.userId}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm">
                            {format(new Date(borrow.borrowDate), 'MMM d, yyyy')}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm">
                            {format(new Date(borrow.dueDate), 'MMM d, yyyy')}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {getBorrowStatusBadge(borrow.status, borrow.dueDate)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            {borrow.status !== "returned" && (
                              <>
                                <Button
                                  variant="link"
                                  className="text-primary hover:text-blue-800 mr-3"
                                  onClick={() => handleReturnBook(borrow.id)}
                                >
                                  Return
                                </Button>
                                <Button variant="link" className="text-info hover:text-blue-800">
                                  <Send className="h-4 w-4 mr-1" /> Notify
                                </Button>
                              </>
                            )}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={6} className="text-center py-4">No borrowed books found</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
