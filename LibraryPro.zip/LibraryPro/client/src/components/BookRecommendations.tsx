import React, { useState } from 'react';
import { useRecommendations, usePersonalRecommendations, RecommendationOptions } from '@/hooks/useRecommendations';
import useAuth from '@/hooks/useAuth';
import { Book } from '@shared/schema';
import BookCard from './BookCard';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { Book as BookIcon, Hash, BookOpen } from 'lucide-react';

interface BookRecommendationsProps {
  type?: 'general' | 'personal' | 'similar';
  title?: string;
  genre?: string;
  bookId?: number;
  limit?: number;
  showFilters?: boolean;
}

export default function BookRecommendations({
  type = 'general',
  title,
  genre: initialGenre,
  bookId,
  limit = 4,
  showFilters = false
}: BookRecommendationsProps) {
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const [genre, setGenre] = useState<string | undefined>(initialGenre);
  const [readLevel, setReadLevel] = useState<'easy' | 'medium' | 'advanced' | undefined>(undefined);
  
  // Options for the recommendation query
  const options: RecommendationOptions = {
    genre,
    readLevel,
    limit,
    similarToBookId: type === 'similar' ? bookId : undefined
  };
  
  // Use the appropriate hook based on recommendation type
  const generalRecommendations = useRecommendations(options);
  const personalRecommendations = usePersonalRecommendations(options);
  
  // Select the active recommendations result
  const recommendations = type === 'personal' 
    ? personalRecommendations 
    : generalRecommendations;
  
  // Handle lending/reserving actions
  const handleBorrow = (book: Book) => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to borrow books",
        variant: "destructive"
      });
      return;
    }
    
    // Implement borrow logic here
  };
  
  const handleReserve = (book: Book) => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to reserve books",
        variant: "destructive"
      });
      return;
    }
    
    // Implement reserve logic here
  };
  
  // Display a loading state
  if (recommendations.isLoading) {
    return (
      <div className="w-full space-y-4">
        <h2 className="text-2xl font-bold">{title || "Book Recommendations"}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array(limit).fill(0).map((_, i) => (
            <div key={i} className="border rounded-lg p-4 space-y-3">
              <Skeleton className="h-40 w-full rounded-md" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
              <Skeleton className="h-8 w-full mt-2" />
            </div>
          ))}
        </div>
      </div>
    );
  }
  
  // Handle error state
  if (recommendations.isError) {
    return (
      <div className="w-full p-6 text-center border rounded-lg bg-muted">
        <BookIcon className="h-10 w-10 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg font-medium">Failed to load recommendations</h3>
        <p className="text-sm text-muted-foreground mt-2">
          {type === 'personal' && !isAuthenticated 
            ? "Please log in to view personalized recommendations." 
            : "Unable to load book recommendations. Please try again later."}
        </p>
        {type === 'personal' && !isAuthenticated && (
          <Button className="mt-4" variant="outline" onClick={() => window.location.href = '/login'}>
            Log In
          </Button>
        )}
      </div>
    );
  }
  
  // No data
  if (!recommendations.data || recommendations.data.books.length === 0) {
    return (
      <div className="w-full p-6 text-center border rounded-lg bg-muted">
        <BookOpen className="h-10 w-10 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg font-medium">No recommendations available</h3>
        <p className="text-sm text-muted-foreground mt-2">
          {type === 'personal' 
            ? "We don't have enough data to make personalized recommendations yet." 
            : "No books found matching your criteria."}
        </p>
        {showFilters && (
          <Button className="mt-4" variant="outline" onClick={() => {
            setGenre(undefined);
            setReadLevel(undefined);
          }}>
            Clear Filters
          </Button>
        )}
      </div>
    );
  }
  
  return (
    <div className="w-full space-y-4">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
        <div>
          <h2 className="text-2xl font-bold">{title || recommendations.data.message}</h2>
          {genre && <Badge variant="secondary" className="mt-1">{genre}</Badge>}
        </div>
        
        {showFilters && (
          <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
            <Select value={genre} onValueChange={(value) => setGenre(value || undefined)}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="All Genres" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Genres</SelectItem>
                <SelectItem value="Fiction">Fiction</SelectItem>
                <SelectItem value="Non-Fiction">Non-Fiction</SelectItem>
                <SelectItem value="Fantasy">Fantasy</SelectItem>
                <SelectItem value="Science Fiction">Science Fiction</SelectItem>
                <SelectItem value="Mystery">Mystery</SelectItem>
                <SelectItem value="Biography">Biography</SelectItem>
                <SelectItem value="History">History</SelectItem>
                <SelectItem value="Science">Science</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={readLevel} onValueChange={(value: any) => setReadLevel(value || undefined)}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="All Levels" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Levels</SelectItem>
                <SelectItem value="easy">Easy</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="advanced">Advanced</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {recommendations.data.books.map((book) => (
          <BookCard 
            key={book.id} 
            book={book} 
            onBorrow={handleBorrow} 
            onReserve={handleReserve} 
          />
        ))}
      </div>
    </div>
  );
}