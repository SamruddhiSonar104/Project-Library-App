import { cn } from "@/lib/utils";

interface Tab {
  id: string;
  label: string;
}

interface StudentTabNavigationProps {
  tabs: Tab[];
  activeTab: string;
  onChange: (tabId: string) => void;
}

export default function StudentTabNavigation({ tabs, activeTab, onChange }: StudentTabNavigationProps) {
  return (
    <div className="bg-white shadow-sm">
      <div className="container mx-auto">
        <nav className="flex overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              className={cn(
                "px-6 py-4 border-b-2 font-medium text-sm whitespace-nowrap",
                activeTab === tab.id
                  ? "border-primary text-primary"
                  : "border-transparent text-neutral-300"
              )}
              onClick={() => onChange(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>
    </div>
  );
}
