import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Search, Book, Bookmark, History } from "lucide-react";
import StudentHeader from "./StudentHeader";
import StudentTabNavigation from "./StudentTabNavigation";
import BookCard from "./BookCard";
import BookRecommendations from "./BookRecommendations";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns";

export default function StudentView() {
  const [activeTab, setActiveTab] = useState("search");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All Categories");

  const tabs = [
    { id: "search", label: "Search Books" },
    { id: "borrowed", label: "My Borrowed Books" },
    { id: "reserved", label: "My Reservations" },
    { id: "history", label: "History" },
  ];

  // Books query
  const { data: booksData, isLoading: booksLoading } = useQuery({
    queryKey: ["/api/books", searchQuery, selectedCategory],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchQuery) params.append("search", searchQuery);
      if (selectedCategory !== "All Categories") params.append("category", selectedCategory);
      
      const url = `/api/books${params.toString() ? `?${params.toString()}` : ''}`;
      const res = await fetch(url, { credentials: "include" });
      
      if (!res.ok) throw new Error("Failed to fetch books");
      return res.json();
    },
  });

  // Borrowed books query
  const { data: borrowsData, isLoading: borrowsLoading } = useQuery({
    queryKey: ["/api/borrows"],
    queryFn: async () => {
      const res = await fetch('/api/borrows', { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch borrowed books");
      return res.json();
    },
  });

  // Reservations query
  const { data: reservationsData, isLoading: reservationsLoading } = useQuery({
    queryKey: ["/api/reservations"],
    queryFn: async () => {
      const res = await fetch('/api/reservations', { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch reservations");
      return res.json();
    },
  });

  // Borrow book mutation
  const borrowBook = useMutation({
    mutationFn: async (bookId: number) => {
      const res = await apiRequest("POST", "/api/borrows", { bookId });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Book borrowed successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/books"] });
      queryClient.invalidateQueries({ queryKey: ["/api/borrows"] });
      setActiveTab("borrowed");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to borrow book",
        variant: "destructive",
      });
    },
  });

  // Reserve book mutation
  const reserveBook = useMutation({
    mutationFn: async (bookId: number) => {
      const res = await apiRequest("POST", "/api/reservations", { bookId });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Book reserved successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/reservations"] });
      setActiveTab("reserved");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to reserve book",
        variant: "destructive",
      });
    },
  });

  // Return book mutation
  const returnBook = useMutation({
    mutationFn: async (borrowId: number) => {
      const res = await apiRequest("POST", `/api/borrows/${borrowId}/return`, {});
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Book returned successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/books"] });
      queryClient.invalidateQueries({ queryKey: ["/api/borrows"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to return book",
        variant: "destructive",
      });
    },
  });

  // Cancel reservation mutation
  const cancelReservation = useMutation({
    mutationFn: async (reservationId: number) => {
      const res = await apiRequest("PUT", `/api/reservations/${reservationId}`, { status: "denied" });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Reservation cancelled successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/reservations"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to cancel reservation",
        variant: "destructive",
      });
    },
  });

  const handleSearch = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/books"] });
  };

  const handleBorrow = (bookId: number) => {
    borrowBook.mutate(bookId);
  };

  const handleReserve = (bookId: number) => {
    reserveBook.mutate(bookId);
  };

  const handleReturn = (borrowId: number) => {
    returnBook.mutate(borrowId);
  };

  const handleCancelReservation = (reservationId: number) => {
    cancelReservation.mutate(reservationId);
  };

  const handleBorrowReserved = (bookId: number) => {
    borrowBook.mutate(bookId);
  };

  const getBorrowStatusBadge = (status: string, dueDate: string) => {
    const now = new Date();
    const due = new Date(dueDate);

    if (status === "returned") {
      return <Badge className="neutral-badge">Returned</Badge>;
    } else if (now > due) {
      return <Badge className="error-badge">Overdue</Badge>;
    } else if (due.getTime() - now.getTime() < 7 * 24 * 60 * 60 * 1000) { // 7 days
      return <Badge className="warning-badge">Due Soon</Badge>;
    } else {
      return <Badge className="success-badge">Active</Badge>;
    }
  };

  const getReservationStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge className="info-badge">Pending</Badge>;
      case "approved":
        return <Badge className="success-badge">Available</Badge>;
      case "denied":
        return <Badge className="error-badge">Denied</Badge>;
      case "completed":
        return <Badge className="neutral-badge">Completed</Badge>;
      default:
        return <Badge className="info-badge">Pending</Badge>;
    }
  };

  // Mobile tab navigation
  const getMobileIcon = (tabId: string) => {
    switch (tabId) {
      case "search":
        return <Search className="text-xl" />;
      case "borrowed":
        return <Book className="text-xl" />;
      case "reserved":
        return <Bookmark className="text-xl" />;
      case "history":
        return <History className="text-xl" />;
      default:
        return null;
    }
  };

  return (
    <div className="flex flex-col flex-grow">
      <StudentHeader />
      
      <StudentTabNavigation
        tabs={tabs}
        activeTab={activeTab}
        onChange={setActiveTab}
      />
      
      <div className="container mx-auto px-4 py-6 flex-grow pb-16 md:pb-6">
        {/* Search Books Tab */}
        {activeTab === "search" && (
          <div>
            <div className="bg-white rounded-lg shadow-md p-4 mb-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-grow">
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                      <Search className="text-neutral-300" />
                    </span>
                    <Input
                      type="text"
                      className="w-full pl-10 pr-4 py-2"
                      placeholder="Search by title, author, or ISBN"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Select
                    value={selectedCategory}
                    onValueChange={setSelectedCategory}
                  >
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="All Categories" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="All Categories">All Categories</SelectItem>
                      <SelectItem value="Fiction">Fiction</SelectItem>
                      <SelectItem value="Non-Fiction">Non-Fiction</SelectItem>
                      <SelectItem value="Science Fiction">Science Fiction</SelectItem>
                      <SelectItem value="History">History</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button onClick={handleSearch}>Filter</Button>
                </div>
              </div>
            </div>
            
            {/* Book Recommendations */}
            <div className="mb-10">
              <BookRecommendations 
                type="personal" 
                title="Recommended for You" 
                limit={4} 
              />
            </div>
            
            <h2 className="text-xl font-medium mb-4">Available Books</h2>
            
            {booksLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="bg-white rounded-lg shadow-md overflow-hidden">
                    <div className="w-full h-48 bg-neutral-200 animate-pulse"></div>
                    <div className="p-4">
                      <div className="h-6 bg-neutral-200 rounded animate-pulse mb-2"></div>
                      <div className="h-4 bg-neutral-200 rounded animate-pulse mb-2"></div>
                      <div className="h-12 bg-neutral-200 rounded animate-pulse mb-4"></div>
                      <div className="flex justify-between items-center">
                        <div className="h-4 w-20 bg-neutral-200 rounded animate-pulse"></div>
                        <div className="h-8 w-20 bg-neutral-200 rounded animate-pulse"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {booksData && Array.isArray(booksData) && booksData.length > 0 ? (
                  booksData.map((book: any) => (
                    <BookCard
                      key={book.id}
                      book={book}
                      onBorrow={() => handleBorrow(book.id)}
                      onReserve={() => handleReserve(book.id)}
                    />
                  ))
                ) : (
                  <div className="col-span-3 text-center py-10">
                    <h3 className="text-lg font-medium">No books found</h3>
                    <p className="text-neutral-300">Try changing your search query or category</p>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
        
        {/* Borrowed Books Tab */}
        {activeTab === "borrowed" && (
          <div>
            <h2 className="text-xl font-medium mb-4">My Borrowed Books</h2>
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              {borrowsLoading ? (
                <div className="p-10 text-center">Loading borrowed books...</div>
              ) : borrowsData && borrowsData.borrows && borrowsData.borrows.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-neutral-200">
                    <thead className="bg-neutral-100">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Book Title</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Borrow Date</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Due Date</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Status</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Action</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-neutral-200">
                      {borrowsData.borrows
                        .filter((borrow: any) => borrow.status !== "returned")
                        .map((borrow: any) => (
                          <tr key={borrow.id}>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-medium">{borrow.book?.title}</div>
                              <div className="text-sm text-neutral-300">{borrow.book?.author}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              {format(new Date(borrow.borrowDate), 'MMM d, yyyy')}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              {format(new Date(borrow.dueDate), 'MMM d, yyyy')}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {getBorrowStatusBadge(borrow.status, borrow.dueDate)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              <Button
                                variant="link"
                                className="text-primary hover:text-blue-800"
                                onClick={() => handleReturn(borrow.id)}
                              >
                                Return
                              </Button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-10">
                  <h3 className="text-lg font-medium">No borrowed books</h3>
                  <p className="text-neutral-300">Browse our collection and borrow a book</p>
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* Reservations Tab */}
        {activeTab === "reserved" && (
          <div>
            <h2 className="text-xl font-medium mb-4">My Reservations</h2>
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              {reservationsLoading ? (
                <div className="p-10 text-center">Loading reservations...</div>
              ) : reservationsData && reservationsData.reservations && reservationsData.reservations.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-neutral-200">
                    <thead className="bg-neutral-100">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Book Title</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Reserved Date</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Status</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Action</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-neutral-200">
                      {reservationsData.reservations.map((reservation: any) => (
                        <tr key={reservation.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium">{reservation.book?.title}</div>
                            <div className="text-sm text-neutral-300">{reservation.book?.author}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm">
                            {format(new Date(reservation.reservationDate), 'MMM d, yyyy')}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {getReservationStatusBadge(reservation.status)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm">
                            {reservation.status === "pending" ? (
                              <Button
                                variant="link"
                                className="text-error hover:text-red-800"
                                onClick={() => handleCancelReservation(reservation.id)}
                              >
                                Cancel
                              </Button>
                            ) : reservation.status === "approved" ? (
                              <Button
                                variant="link"
                                className="text-primary hover:text-blue-800"
                                onClick={() => handleBorrowReserved(reservation.book.id)}
                              >
                                Borrow
                              </Button>
                            ) : (
                              <span className="text-neutral-300">-</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-10">
                  <h3 className="text-lg font-medium">No reservations</h3>
                  <p className="text-neutral-300">Reserve books that are currently unavailable</p>
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* History Tab */}
        {activeTab === "history" && (
          <div>
            <h2 className="text-xl font-medium mb-4">Borrowing History</h2>
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              {borrowsLoading ? (
                <div className="p-10 text-center">Loading history...</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-neutral-200">
                    <thead className="bg-neutral-100">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Book Title</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Borrow Date</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Return Date</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-400 uppercase tracking-wider">Status</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-neutral-200">
                      {borrowsData && borrowsData.borrows && borrowsData.borrows
                        .filter((borrow: any) => borrow.status === "returned")
                        .map((borrow: any) => (
                          <tr key={borrow.id}>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-medium">{borrow.book?.title}</div>
                              <div className="text-sm text-neutral-300">{borrow.book?.author}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              {format(new Date(borrow.borrowDate), 'MMM d, yyyy')}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              {borrow.returnDate ? format(new Date(borrow.returnDate), 'MMM d, yyyy') : '-'}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <Badge className="neutral-badge">Returned</Badge>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
      
      {/* Mobile Navigation */}
      <div className="md:hidden bg-white shadow-lg border-t fixed bottom-0 w-full">
        <div className="flex justify-around">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              className={`flex flex-col items-center pt-2 pb-1 ${
                activeTab === tab.id ? "text-primary" : "text-neutral-300"
              }`}
              onClick={() => setActiveTab(tab.id)}
            >
              {getMobileIcon(tab.id)}
              <span className="text-xs">{tab.label.split(" ")[0]}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
