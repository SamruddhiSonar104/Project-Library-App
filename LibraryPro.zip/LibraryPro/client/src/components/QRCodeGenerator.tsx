import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface QRCodeGeneratorProps {
  data: string | object;
  title?: string;
  description?: string;
  downloadFileName?: string;
  size?: number;
}

export default function QRCodeGenerator({
  data,
  title = "QR Code",
  description = "Scan this QR code with a mobile device",
  downloadFileName = "qrcode",
  size = 250
}: QRCodeGeneratorProps) {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [jsonData, setJsonData] = useState<string>('');

  useEffect(() => {
    const generateQR = async () => {
      try {
        // Format data as JSON if it's an object
        const dataString = typeof data === 'object' ? JSON.stringify(data) : data.toString();
        setJsonData(dataString);
        
        // Generate QR code as data URL
        const dataUrl = await QRCode.toDataURL(dataString, {
          width: size,
          margin: 2,
          color: {
            dark: '#000000',
            light: '#ffffff'
          }
        });
        
        setQrDataUrl(dataUrl);
        setError(null);
      } catch (err: any) {
        setError(err.message || 'Failed to generate QR code');
        console.error('QR Code generation error:', err);
      }
    };

    generateQR();
  }, [data, size]);

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = qrDataUrl;
    link.download = `${downloadFileName}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Card className="w-full max-w-sm mx-auto">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      
      <CardContent className="flex flex-col items-center justify-center p-6">
        {error ? (
          <Alert variant="destructive" className="w-full mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ) : qrDataUrl ? (
          <div className="flex flex-col items-center gap-4">
            <img 
              src={qrDataUrl} 
              alt="QR Code" 
              className="border-2 border-gray-200 rounded-md dark:border-gray-700"
            />
            <p className="text-xs text-gray-500 dark:text-gray-400 break-all max-w-[250px] text-center">
              {jsonData.length > 50 ? `${jsonData.substring(0, 50)}...` : jsonData}
            </p>
          </div>
        ) : (
          <div className="w-full h-[250px] flex items-center justify-center bg-gray-100 dark:bg-gray-800 rounded-md">
            <span className="text-gray-500 dark:text-gray-400">Generating QR code...</span>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="flex justify-center">
        <Button
          onClick={handleDownload}
          disabled={!qrDataUrl || !!error}
          className="w-full"
        >
          Download QR Code
        </Button>
      </CardFooter>
    </Card>
  );
}