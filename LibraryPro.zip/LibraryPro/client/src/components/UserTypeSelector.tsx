import { useState } from "react";
import { Button } from "@/components/ui/button";

interface UserTypeSelectorProps {
  activeView: string;
  onViewChange: (view: string) => void;
}

export default function UserTypeSelector({ activeView, onViewChange }: UserTypeSelectorProps) {
  return (
    <div className="bg-white p-4 shadow-md flex justify-center">
      <div className="inline-flex rounded-md shadow-sm" role="group">
        <Button
          variant={activeView === "student" ? "default" : "outline"}
          className={`rounded-l-lg ${
            activeView === "student" ? "bg-primary text-white" : "bg-white text-neutral-400 hover:bg-neutral-100"
          }`}
          onClick={() => onViewChange("student")}
        >
          Student View
        </Button>
        <Button
          variant={activeView === "admin" ? "default" : "outline"}
          className={`rounded-r-lg ${
            activeView === "admin" ? "bg-primary text-white" : "bg-white text-neutral-400 hover:bg-neutral-100"
          }`}
          onClick={() => onViewChange("admin")}
        >
          Admin View
        </Button>
      </div>
    </div>
  );
}
