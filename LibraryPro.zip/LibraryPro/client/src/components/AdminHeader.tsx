import { Menu, Bell, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import useAuth from "@/hooks/useAuth";

interface AdminHeaderProps {
  onMenuClick: () => void;
}

export default function AdminHeader({ onMenuClick }: AdminHeaderProps) {
  const { user } = useAuth();
  
  return (
    <header className="bg-white border-b shadow-sm p-4 flex justify-between items-center">
      <div>
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden flex items-center text-neutral-400"
          onClick={onMenuClick}
        >
          <Menu />
        </Button>
      </div>
      <div className="flex items-center gap-4">
        <Bell className="h-5 w-5" />
        <User className="h-5 w-5" />
        <span className="hidden md:inline-block">{user?.fullName || "Admin User"}</span>
      </div>
    </header>
  );
}
