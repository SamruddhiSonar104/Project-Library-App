import { cn } from "@/lib/utils";
import { Book, Users, Bookmark, History, LayoutDashboard } from "lucide-react";

interface SidebarItem {
  id: string;
  label: string;
  icon: React.ReactNode;
}

interface AdminSidebarProps {
  isVisible: boolean;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function AdminSidebar({ isVisible, activeTab, onTabChange }: AdminSidebarProps) {
  const sidebarItems: SidebarItem[] = [
    { id: "dashboard", label: "Dashboard", icon: <LayoutDashboard className="mr-2 h-5 w-5" /> },
    { id: "books", label: "Manage Books", icon: <Book className="mr-2 h-5 w-5" /> },
    { id: "users", label: "Manage Users", icon: <Users className="mr-2 h-5 w-5" /> },
    { id: "reservations", label: "Reservations", icon: <Bookmark className="mr-2 h-5 w-5" /> },
    { id: "borrowed", label: "Borrowed Books", icon: <History className="mr-2 h-5 w-5" /> },
  ];

  return (
    <aside
      className={cn(
        "md:flex flex-col w-64 bg-neutral-400 text-white transition-all",
        isVisible ? "flex" : "hidden"
      )}
    >
      <div className="p-4 flex items-center gap-2 border-b border-neutral-300">
        <Book />
        <h1 className="text-lg font-bold">Library Admin</h1>
      </div>
      <nav className="flex-grow p-4">
        <ul className="space-y-2">
          {sidebarItems.map((item) => (
            <li key={item.id}>
              <button
                className={cn(
                  "flex items-center w-full px-4 py-2 rounded-lg",
                  activeTab === item.id
                    ? "bg-primary text-white"
                    : "bg-neutral-100 text-neutral-400"
                )}
                onClick={() => onTabChange(item.id)}
              >
                {item.icon}
                {item.label}
              </button>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
}
