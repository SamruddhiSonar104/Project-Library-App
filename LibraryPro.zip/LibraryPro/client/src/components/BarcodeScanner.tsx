import { useState, useEffect, useRef } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Types for the scanner results
export type ScannerResult = {
  bookId?: number;
  userId?: number;
  isbn?: string;
  scannedText: string;
};

interface BarcodeScannerProps {
  onScanSuccess: (result: ScannerResult) => void;
  onScanFailure?: (error: string) => void;
  mode?: 'book' | 'user';
}

const BarcodeScanner = ({ 
  onScanSuccess, 
  onScanFailure,
  mode = 'book'
}: BarcodeScannerProps) => {
  const [isScanning, setIsScanning] = useState(false);
  const [scannerInitialized, setScannerInitialized] = useState(false);
  const [selectedCamera, setSelectedCamera] = useState<string | null>(null);
  const [cameras, setCameras] = useState<Array<{ id: string; label: string }>>([]);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const scannerContainerId = 'scanner-container';
  
  // Initialize the scanner on component mount
  useEffect(() => {
    return () => {
      // Clean up the scanner on unmount
      if (scannerRef.current && scannerInitialized) {
        try {
          scannerRef.current.stop();
        } catch (error) {
          console.error('Error stopping scanner:', error);
        }
      }
    };
  }, [scannerInitialized]);
  
  // Get available cameras
  useEffect(() => {
    if (!scannerRef.current) {
      scannerRef.current = new Html5Qrcode(scannerContainerId);
    }
    
    Html5Qrcode.getCameras()
      .then(devices => {
        if (devices && devices.length) {
          setCameras(devices.map(device => ({
            id: device.id,
            label: device.label || `Camera ${device.id}`
          })));
          setSelectedCamera(devices[0].id);
        }
      })
      .catch(err => {
        console.error('Error getting cameras:', err);
        if (onScanFailure) {
          onScanFailure('Could not access camera. Please make sure you have granted camera permissions.');
        }
      });
  }, [onScanFailure]);
  
  const startScanner = () => {
    if (!scannerRef.current || !selectedCamera) return;
    
    setIsScanning(true);
    
    const config = { fps: 10, qrbox: { width: 250, height: 250 } };
    
    scannerRef.current.start(
      selectedCamera,
      config,
      handleScanSuccess,
      handleScanFailure
    )
    .then(() => {
      setScannerInitialized(true);
    })
    .catch((err) => {
      setIsScanning(false);
      console.error('Error starting scanner:', err);
      if (onScanFailure) {
        onScanFailure('Failed to start scanner. Please check camera permissions.');
      }
    });
  };
  
  const stopScanner = () => {
    if (scannerRef.current && scannerInitialized) {
      scannerRef.current.stop()
        .then(() => {
          setIsScanning(false);
        })
        .catch((err) => {
          console.error('Error stopping scanner:', err);
        });
    }
  };
  
  const handleScanSuccess = (decodedText: string) => {
    // Process the scanned barcode or QR code
    let result: ScannerResult = { scannedText: decodedText };
    
    // Try to parse as JSON first (for QR codes with JSON data)
    try {
      const parsed = JSON.parse(decodedText);
      if (mode === 'book' && parsed.isbn) {
        result.isbn = parsed.isbn;
      } else if (mode === 'book' && parsed.bookId) {
        result.bookId = parsed.bookId;
      } else if (mode === 'user' && parsed.userId) {
        result.userId = parsed.userId;
      }
    } catch (e) {
      // Not JSON, treat as plain text (ISBN or ID)
      if (mode === 'book') {
        // Check if it looks like an ISBN (mostly numeric)
        if (/^[0-9-]{10,17}$/.test(decodedText)) {
          result.isbn = decodedText;
        } else {
          // Try to parse as book ID
          const possibleId = parseInt(decodedText);
          if (!isNaN(possibleId)) {
            result.bookId = possibleId;
          }
        }
      } else if (mode === 'user') {
        // Try to parse as user ID
        const possibleId = parseInt(decodedText);
        if (!isNaN(possibleId)) {
          result.userId = possibleId;
        }
      }
    }
    
    // Stop scanner after successful scan
    stopScanner();
    
    // Call the success callback
    onScanSuccess(result);
  };
  
  const handleScanFailure = (error: string) => {
    // Only report errors that are not expected during normal scanning
    if (error.includes('No QR code found')) {
      return; // This is normal when nothing is in view
    }
    
    console.error('Scan error:', error);
    if (onScanFailure) {
      onScanFailure(error);
    }
  };
  
  const handleCameraChange = (cameraId: string) => {
    if (isScanning) {
      stopScanner();
    }
    setSelectedCamera(cameraId);
  };
  
  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>{mode === 'book' ? 'Scan Book' : 'Scan User Card'}</CardTitle>
        <CardDescription>
          {mode === 'book' 
            ? 'Scan a barcode or QR code on a book to check in/out' 
            : 'Scan a user library card to identify the user'}
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        {cameras.length > 0 && (
          <div className="mb-4">
            <Tabs defaultValue={cameras[0]?.id} onValueChange={handleCameraChange}>
              <TabsList className="grid grid-cols-2">
                {cameras.map(camera => (
                  <TabsTrigger key={camera.id} value={camera.id} disabled={isScanning}>
                    {camera.label.substring(0, 15)}
                    {camera.label.length > 15 ? '...' : ''}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>
        )}
        
        <div id={scannerContainerId} className="w-full h-64 bg-slate-100 dark:bg-slate-800 rounded-md overflow-hidden flex items-center justify-center">
          {!isScanning && !cameras.length && (
            <p className="text-center text-slate-500">No cameras detected</p>
          )}
          {!isScanning && cameras.length > 0 && (
            <p className="text-center text-slate-500">Camera ready. Click Start to scan.</p>
          )}
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={() => window.history.back()}>
          Cancel
        </Button>
        
        {!isScanning ? (
          <Button onClick={startScanner} disabled={!selectedCamera}>
            Start Scanning
          </Button>
        ) : (
          <Button variant="destructive" onClick={stopScanner}>
            Stop Scanning
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default BarcodeScanner;