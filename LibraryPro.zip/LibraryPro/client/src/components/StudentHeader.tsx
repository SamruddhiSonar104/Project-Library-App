import { Book, User } from "lucide-react";
import useAuth from "@/hooks/useAuth";

export default function StudentHeader() {
  const { user } = useAuth();

  return (
    <header className="bg-primary text-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <Book className="mr-2" />
          <h1 className="text-xl font-bold">Library Hub</h1>
        </div>
        <div className="flex items-center">
          <User className="mr-2" />
          <span className="hidden md:inline-block">{user?.fullName || "User"}</span>
        </div>
      </div>
    </header>
  );
}
