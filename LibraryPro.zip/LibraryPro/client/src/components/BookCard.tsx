import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Book } from "@shared/schema";

interface BookCardProps {
  book: Book;
  onBorrow: (book: Book) => void;
  onReserve: (book: Book) => void;
}

export default function BookCard({ book, onBorrow, onReserve }: BookCardProps) {
  const getAvailabilityBadge = () => {
    if (book.availableCopies > 1) {
      return <Badge className="success-badge">Available</Badge>;
    } else if (book.availableCopies === 1) {
      return <Badge className="warning-badge">1 Left</Badge>;
    } else {
      return <Badge className="error-badge">Unavailable</Badge>;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      {book.coverImage && (
        <img
          src={book.coverImage}
          alt={`Cover of ${book.title}`}
          className="w-full h-48 object-cover"
        />
      )}
      <div className="p-4">
        <div className="flex justify-between items-start">
          <h3 className="font-bold text-lg line-clamp-1">{book.title}</h3>
          {getAvailabilityBadge()}
        </div>
        <p className="text-sm text-neutral-300 mb-2">{book.author}</p>
        <p className="text-sm mb-4 line-clamp-2">{book.description}</p>
        <div className="flex justify-between items-center">
          <div className="text-sm">
            <span className="font-medium">Copies: </span>
            <span>{book.availableCopies}</span>/<span>{book.totalCopies}</span>
          </div>
          {book.availableCopies > 0 ? (
            <Button 
              className="bg-primary text-white px-3 py-1 rounded-lg text-sm h-8"
              onClick={() => onBorrow(book)}
            >
              Borrow
            </Button>
          ) : (
            <Button 
              variant="destructive"
              className="bg-secondary text-white px-3 py-1 rounded-lg text-sm h-8"
              onClick={() => onReserve(book)}
            >
              Reserve
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
