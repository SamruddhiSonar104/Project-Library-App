import { useEffect } from "react";
import { useLocation } from "wouter";
import StudentView from "@/components/StudentView";
import useAuth from "@/hooks/useAuth";
import { Loader2 } from "lucide-react";

export default function StudentDashboard() {
  const { isAuthenticated, isLoading, user } = useAuth();
  const [_, navigate] = useLocation();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate("/login");
    } else if (!isLoading && isAuthenticated && user?.role === "admin") {
      navigate("/admin-dashboard");
    }
  }, [isAuthenticated, isLoading, navigate, user]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">Loading your dashboard...</span>
      </div>
    );
  }

  if (!isAuthenticated || user?.role !== "student") {
    return null; // Will be redirected by the useEffect
  }

  return <StudentView />;
}
