import { useEffect } from "react";
import { useLocation } from "wouter";
import AdminView from "@/components/AdminView";
import useAuth from "@/hooks/useAuth";
import { Loader2 } from "lucide-react";

export default function AdminDashboard() {
  const { isAuthenticated, isLoading, user } = useAuth();
  const [_, navigate] = useLocation();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate("/login");
    } else if (!isLoading && isAuthenticated && user?.role !== "admin") {
      navigate("/student-dashboard");
    }
  }, [isAuthenticated, isLoading, navigate, user]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">Loading admin dashboard...</span>
      </div>
    );
  }

  if (!isAuthenticated || user?.role !== "admin") {
    return null; // Will be redirected by the useEffect
  }

  return <AdminView />;
}
