import { useState } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import BarcodeScanner, { ScannerResult } from "@/components/BarcodeScanner";
import { apiRequest, getQueryFn } from "@/lib/queryClient";
import { AlertCircle, Check } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import useAuth from "@/hooks/useAuth";
import { useMutation, useQueryClient } from "@tanstack/react-query";

export default function ScanBook() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [error, setError] = useState<string | null>(null);
  const [scanResult, setScanResult] = useState<ScannerResult | null>(null);
  const [isCheckingOut, setIsCheckingOut] = useState(true);
  
  // Mutation for checking out a book
  const checkOutMutation = useMutation({
    mutationFn: async (data: { bookId: number; userId: number }) => {
      return await apiRequest('/api/borrows', 'POST', {
        bookId: data.bookId,
        userId: data.userId,
        dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000) // 14 days from now
      }, {
        enableOfflineMode: true,
        optimisticData: {
          id: Math.floor(Math.random() * -1000), // Temporary negative ID for offline
          bookId: data.bookId,
          userId: data.userId,
          dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
          status: 'active',
          borrowDate: new Date()
        }
      });
    },
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "Book has been checked out successfully.",
        variant: "default",
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/books'] });
      queryClient.invalidateQueries({ queryKey: ['/api/borrows'] });
      
      // Navigate back to the dashboard
      if (user?.role === 'admin') {
        navigate('/admin');
      } else {
        navigate('/dashboard');
      }
    },
    onError: (error: any) => {
      setError(error.message || "Failed to check out book. Please try again.");
    }
  });
  
  // Mutation for checking in a book
  const checkInMutation = useMutation({
    mutationFn: async (borrowId: number) => {
      return await apiRequest(`/api/borrows/${borrowId}/return`, 'POST', {}, {
        enableOfflineMode: true,
        optimisticData: {
          id: borrowId,
          status: 'returned',
          returnDate: new Date()
        }
      });
    },
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "Book has been returned successfully.",
        variant: "default",
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/books'] });
      queryClient.invalidateQueries({ queryKey: ['/api/borrows'] });
      
      // Navigate back to the dashboard
      if (user?.role === 'admin') {
        navigate('/admin');
      } else {
        navigate('/dashboard');
      }
    },
    onError: (error: any) => {
      setError(error.message || "Failed to return book. Please try again.");
    }
  });
  
  const handleScanSuccess = async (result: ScannerResult) => {
    setScanResult(result);
    setError(null);
    
    if (!result.bookId && !result.isbn) {
      setError("Invalid scan result. Please try again.");
      return;
    }
    
    try {
      // If we have an ISBN but not a book ID, look up the book
      if (result.isbn && !result.bookId) {
        const response = await apiRequest(`/api/books/isbn/${result.isbn}`, 'GET');
        const responseData = await response.json();
        
        if (responseData && responseData.id) {
          result.bookId = responseData.id;
        } else {
          setError("Book not found with this ISBN. Please try again or enter manually.");
          return;
        }
      }
      
      if (!result.bookId) {
        setError("Could not identify book. Please try again or enter manually.");
        return;
      }
      
      // For check-out, we need a user ID - if admin, we'll need to scan user card next
      if (isCheckingOut) {
        if (user?.role === 'admin') {
          // For admins, we'll navigate to scan user
          navigate(`/scan-user?bookId=${result.bookId}`);
        } else {
          // For students, use their own ID
          checkOutMutation.mutate({ bookId: result.bookId, userId: user!.id });
        }
      } else {
        // For check-in, look up the borrow record
        const response = await apiRequest(`/api/borrows?bookId=${result.bookId}`, 'GET');
        const borrows = await response.json();
        
        if (borrows && Array.isArray(borrows) && borrows.length > 0) {
          // Find the active borrow for this book
          const activeBorrow = borrows.find((b: any) => b.status === 'active');
          
          if (activeBorrow) {
            checkInMutation.mutate(activeBorrow.id);
          } else {
            setError("No active borrowing record found for this book.");
          }
        } else {
          setError("No borrowing record found for this book.");
        }
      }
    } catch (err: any) {
      setError(err.message || "An error occurred processing the scan. Please try again.");
    }
  };
  
  const handleScanFailure = (error: string) => {
    setError(error);
  };
  
  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold mb-6 text-center">
        {isCheckingOut ? "Scan to Check Out Book" : "Scan to Return Book"}
      </h1>
      
      <div className="flex justify-center mb-6">
        <div className="grid grid-cols-2 gap-2">
          <Button
            variant={isCheckingOut ? "default" : "outline"}
            onClick={() => setIsCheckingOut(true)}
          >
            Check Out
          </Button>
          <Button
            variant={!isCheckingOut ? "default" : "outline"}
            onClick={() => setIsCheckingOut(false)}
          >
            Return
          </Button>
        </div>
      </div>
      
      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      {scanResult && scanResult.bookId && (
        <Alert className="mb-6">
          <Check className="h-4 w-4" />
          <AlertTitle>Scan Successful</AlertTitle>
          <AlertDescription>
            Book ID: {scanResult.bookId}
            {scanResult.isbn && ` (ISBN: ${scanResult.isbn})`}
          </AlertDescription>
        </Alert>
      )}
      
      <BarcodeScanner
        onScanSuccess={handleScanSuccess}
        onScanFailure={handleScanFailure}
        mode="book"
      />
      
      <div className="mt-6 text-center">
        <Button variant="outline" onClick={() => window.history.back()}>
          Cancel
        </Button>
      </div>
    </div>
  );
}