import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import BarcodeScanner, { ScannerResult } from "@/components/BarcodeScanner";
import { apiRequest, getQueryFn } from "@/lib/queryClient";
import { AlertCircle, Check } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import useAuth from "@/hooks/useAuth";
import { useMutation, useQueryClient } from "@tanstack/react-query";

export default function ScanUser() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [location] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [error, setError] = useState<string | null>(null);
  const [scanResult, setScanResult] = useState<ScannerResult | null>(null);
  const [bookId, setBookId] = useState<number | null>(null);
  
  // Parse bookId from URL params
  useEffect(() => {
    const params = new URLSearchParams(location.split('?')[1]);
    const bookIdParam = params.get('bookId');
    
    if (bookIdParam) {
      setBookId(parseInt(bookIdParam));
    } else {
      setError("No book ID provided. Please scan a book first.");
    }
  }, [location]);
  
  // Mutation for checking out a book
  const checkOutMutation = useMutation({
    mutationFn: async (data: { bookId: number; userId: number }) => {
      return await apiRequest('/api/borrows', 'POST', {
        bookId: data.bookId,
        userId: data.userId,
        dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000) // 14 days from now
      }, {
        enableOfflineMode: true,
        optimisticData: {
          id: Math.floor(Math.random() * -1000), // Temporary negative ID for offline
          bookId: data.bookId,
          userId: data.userId,
          dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
          status: 'active',
          borrowDate: new Date()
        }
      });
    },
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "Book has been checked out successfully.",
        variant: "default",
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/books'] });
      queryClient.invalidateQueries({ queryKey: ['/api/borrows'] });
      
      // Navigate back to the dashboard
      navigate('/admin');
    },
    onError: (error: any) => {
      setError(error.message || "Failed to check out book. Please try again.");
    }
  });
  
  const handleScanSuccess = async (result: ScannerResult) => {
    setScanResult(result);
    setError(null);
    
    if (!result.userId) {
      setError("Invalid scan result. Could not detect a user ID.");
      return;
    }
    
    try {
      // Verify the user exists
      const userResponse = await apiRequest(`/api/users/${result.userId}`, 'GET');
      const userData = await userResponse.json();
      
      if (!userData || !userData.id) {
        setError("User not found. Please try again or enter manually.");
        return;
      }
      
      if (!bookId) {
        setError("No book ID found. Please go back and scan a book first.");
        return;
      }
      
      // Check out the book for this user
      checkOutMutation.mutate({ bookId, userId: result.userId });
      
    } catch (err: any) {
      setError(err.message || "An error occurred processing the scan. Please try again.");
    }
  };
  
  const handleScanFailure = (error: string) => {
    setError(error);
  };
  
  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold mb-6 text-center">
        Scan Student Library Card
      </h1>
      
      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      {bookId && (
        <Alert className="mb-6">
          <Check className="h-4 w-4" />
          <AlertTitle>Book Selected</AlertTitle>
          <AlertDescription>
            Ready to check out book ID: {bookId}
          </AlertDescription>
        </Alert>
      )}
      
      {scanResult && scanResult.userId && (
        <Alert className="mb-6">
          <Check className="h-4 w-4" />
          <AlertTitle>Scan Successful</AlertTitle>
          <AlertDescription>
            Student ID: {scanResult.userId}
          </AlertDescription>
        </Alert>
      )}
      
      <BarcodeScanner
        onScanSuccess={handleScanSuccess}
        onScanFailure={handleScanFailure}
        mode="user"
      />
      
      <div className="mt-6 text-center">
        <Button variant="outline" onClick={() => navigate('/scan-book')}>
          Back to Book Scan
        </Button>
      </div>
    </div>
  );
}