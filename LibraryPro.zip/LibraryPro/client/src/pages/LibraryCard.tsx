import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import useAuth from '@/hooks/useAuth';
import QRCodeGenerator from '@/components/QRCodeGenerator';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function LibraryCard() {
  const { user, isLoading } = useAuth();
  const [, navigate] = useLocation();
  const [qrData, setQrData] = useState<any>(null);
  
  useEffect(() => {
    if (!isLoading && !user) {
      navigate('/login');
    } else if (user) {
      // Format the data we want to include in the QR code
      const libraryCardData = {
        userId: user.id,
        username: user.username,
        fullName: user.fullName,
        role: user.role,
        cardType: 'library'
      };
      
      setQrData(libraryCardData);
    }
  }, [user, isLoading, navigate]);
  
  if (isLoading) {
    return (
      <div className="container mx-auto py-12 px-4">
        <div className="w-full max-w-lg mx-auto flex justify-center">
          <div className="text-center">Loading...</div>
        </div>
      </div>
    );
  }
  
  if (!user) {
    return (
      <div className="container mx-auto py-12 px-4">
        <Alert variant="destructive" className="max-w-lg mx-auto">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Authentication Required</AlertTitle>
          <AlertDescription>
            You need to be logged in to view your library card.
          </AlertDescription>
        </Alert>
      </div>
    );
  }
  
  // Get initials for avatar
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase();
  };

  const userInitials = getInitials(user.fullName);
  
  return (
    <div className="container mx-auto py-12 px-4">
      <h1 className="text-3xl font-bold text-center mb-8">Your Library Card</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-4xl mx-auto">
        <Card className="w-full">
          <CardHeader>
            <div className="flex items-center gap-4">
              <Avatar className="h-12 w-12">
                <AvatarFallback>{userInitials}</AvatarFallback>
              </Avatar>
              <div>
                <CardTitle>{user.fullName}</CardTitle>
                <CardDescription className="mt-1">{user.role === 'admin' ? 'Staff' : 'Student'}</CardDescription>
              </div>
            </div>
          </CardHeader>
          
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">ID</p>
                  <p className="text-lg">{user.id}</p>
                </div>
                
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Username</p>
                  <p className="text-lg">{user.username}</p>
                </div>
              </div>
              
              <div>
                <p className="text-sm font-medium text-muted-foreground">Email</p>
                <p className="text-lg">{user.email}</p>
              </div>
            </div>
          </CardContent>
          
          <CardFooter>
            <div className="text-xs text-muted-foreground">
              This card serves as your official library identification. Present this card or its QR code when checking out books.
            </div>
          </CardFooter>
        </Card>
        
        <div className="flex flex-col justify-center">
          {qrData && (
            <QRCodeGenerator
              data={qrData}
              title="Digital Library Card"
              description="Scan this QR code at the library to check out books"
              downloadFileName={`library-card-${user.username}`}
              size={230}
            />
          )}
          
          <div className="mt-6 text-center">
            <Button variant="outline" onClick={() => window.print()}>
              Print Library Card
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}