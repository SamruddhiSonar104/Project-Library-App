import { useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Book } from "lucide-react";
import useAuth from "@/hooks/useAuth";

export default function Home() {
  const { isAuthenticated, user } = useAuth();
  const [_, navigate] = useLocation();

  useEffect(() => {
    if (isAuthenticated) {
      if (user?.role === "admin") {
        navigate("/admin-dashboard");
      } else {
        navigate("/student-dashboard");
      }
    }
  }, [isAuthenticated, user, navigate]);

  return (
    <div className="min-h-screen bg-neutral-100 flex flex-col">
      <header className="bg-primary text-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <Book className="mr-2" />
            <h1 className="text-xl font-bold">Library Hub</h1>
          </div>
          <div className="flex items-center space-x-2">
            <Button 
              variant="outline" 
              className="text-white border-white hover:bg-white hover:text-primary"
              onClick={() => navigate("/login")}
            >
              Login
            </Button>
            <Button 
              className="bg-white text-primary hover:bg-neutral-100"
              onClick={() => navigate("/register")}
            >
              Register
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-grow flex items-center justify-center px-4 py-12">
        <Card className="max-w-4xl w-full">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <Book className="w-16 h-16 mx-auto mb-4 text-primary" />
              <h1 className="text-3xl font-bold mb-2">Welcome to Library Hub</h1>
              <p className="text-neutral-400 max-w-lg mx-auto">
                Your digital library management system for seamlessly browsing, borrowing, and managing books.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6 mt-8">
              <div className="p-6 bg-neutral-50 rounded-lg">
                <h2 className="text-xl font-bold mb-2">For Students</h2>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-start">
                    <span className="bg-primary bg-opacity-10 p-1 rounded-full text-primary mr-2 mt-0.5">✓</span>
                    <span>Browse and search for books</span>
                  </li>
                  <li className="flex items-start">
                    <span className="bg-primary bg-opacity-10 p-1 rounded-full text-primary mr-2 mt-0.5">✓</span>
                    <span>Check book availability</span>
                  </li>
                  <li className="flex items-start">
                    <span className="bg-primary bg-opacity-10 p-1 rounded-full text-primary mr-2 mt-0.5">✓</span>
                    <span>Borrow and reserve books</span>
                  </li>
                  <li className="flex items-start">
                    <span className="bg-primary bg-opacity-10 p-1 rounded-full text-primary mr-2 mt-0.5">✓</span>
                    <span>Track your borrowing history</span>
                  </li>
                </ul>
                <Button className="w-full" onClick={() => navigate("/register")}>
                  Register as Student
                </Button>
              </div>

              <div className="p-6 bg-neutral-50 rounded-lg">
                <h2 className="text-xl font-bold mb-2">For Librarians</h2>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-start">
                    <span className="bg-primary bg-opacity-10 p-1 rounded-full text-primary mr-2 mt-0.5">✓</span>
                    <span>Manage book catalog</span>
                  </li>
                  <li className="flex items-start">
                    <span className="bg-primary bg-opacity-10 p-1 rounded-full text-primary mr-2 mt-0.5">✓</span>
                    <span>Approve or deny reservations</span>
                  </li>
                  <li className="flex items-start">
                    <span className="bg-primary bg-opacity-10 p-1 rounded-full text-primary mr-2 mt-0.5">✓</span>
                    <span>Track checkouts and returns</span>
                  </li>
                  <li className="flex items-start">
                    <span className="bg-primary bg-opacity-10 p-1 rounded-full text-primary mr-2 mt-0.5">✓</span>
                    <span>Manage user accounts</span>
                  </li>
                </ul>
                <Button className="w-full" onClick={() => navigate("/login")}>
                  Login as Librarian
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      <footer className="bg-white py-6">
        <div className="container mx-auto px-4 text-center text-neutral-400 text-sm">
          &copy; 2023 Library Hub. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
