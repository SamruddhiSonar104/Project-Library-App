import { Switch, Route, useLocation, useRoute } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import StudentDashboard from "@/pages/StudentDashboard";
import AdminDashboard from "@/pages/AdminDashboard";
import ScanBook from "@/pages/ScanBook";
import ScanUser from "@/pages/ScanUser";
import LibraryCard from "@/pages/LibraryCard";
import useAuth from "@/hooks/useAuth";
import { useEffect } from "react";

// Redirect route component
function RedirectRoute({ path }: { path: string }) {
  const [, navigate] = useLocation();
  
  useEffect(() => {
    navigate(path);
  }, [navigate, path]);
  
  return null;
}

// Protected route component
function ProtectedRoute({ component: Component, adminOnly = false, ...rest }: any) {
  const { user, isLoading } = useAuth();
  const [, navigate] = useLocation();
  const [match] = useRoute(rest.path);

  useEffect(() => {
    // Wait until auth is loaded
    if (isLoading) return;
    
    // Redirect if not authenticated
    if (!user && match) {
      navigate("/login");
      return;
    }
    
    // If admin-only route and user is not admin, redirect
    if (adminOnly && user?.role !== "admin" && match) {
      navigate("/dashboard");
    }
  }, [user, isLoading, adminOnly, match, navigate]);

  if (isLoading) {
    return <div className="container mx-auto p-8 text-center">Loading...</div>;
  }

  // Only render the component if user is authenticated (and admin if required)
  if (!user || (adminOnly && user.role !== "admin")) {
    return null;
  }

  return <Component {...rest} />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      
      {/* Student routes */}
      <Route path="/dashboard">
        <ProtectedRoute component={StudentDashboard} path="/dashboard" />
      </Route>
      
      {/* Admin routes */}
      <Route path="/admin">
        <ProtectedRoute component={AdminDashboard} path="/admin" adminOnly={true} />
      </Route>
      
      {/* Scanner routes */}
      <Route path="/scan-book">
        <ProtectedRoute component={ScanBook} path="/scan-book" />
      </Route>
      
      <Route path="/scan-user">
        <ProtectedRoute component={ScanUser} path="/scan-user" adminOnly={true} />
      </Route>
      
      {/* Library Card route */}
      <Route path="/library-card">
        <ProtectedRoute component={LibraryCard} path="/library-card" />
      </Route>
      
      {/* Legacy routes - redirect */}
      <Route path="/student-dashboard">
        <RedirectRoute path="/dashboard" />
      </Route>
      
      <Route path="/admin-dashboard">
        <RedirectRoute path="/admin" />
      </Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
