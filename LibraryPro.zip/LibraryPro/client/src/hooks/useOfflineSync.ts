import { useState, useEffect, useCallback } from 'react';
import offlineSync from '@/lib/offlineSync';

type SyncStatus = 'idle' | 'syncing' | 'success' | 'error';

interface SyncState {
  status: SyncStatus;
  queueLength: number;
  isOnline: boolean;
  lastMessage?: string;
}

/**
 * Hook to interact with the offline sync system
 * Provides functions to add operations to the sync queue and check sync status
 */
export default function useOfflineSync() {
  const [syncState, setSyncState] = useState<SyncState>({
    ...offlineSync.getStatus(),
    isOnline: navigator.onLine
  });

  // Subscribe to status changes
  useEffect(() => {
    const unsubscribe = offlineSync.subscribe((status, message) => {
      setSyncState(prev => ({
        ...prev,
        status,
        queueLength: offlineSync.getQueue().length,
        lastMessage: message
      }));
    });

    // Handle online/offline status changes
    const handleOnline = () => {
      setSyncState(prev => ({ ...prev, isOnline: true }));
    };

    const handleOffline = () => {
      setSyncState(prev => ({ ...prev, isOnline: false }));
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      unsubscribe();
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  /**
   * Add an operation to the sync queue to be processed when online
   */
  const addToSyncQueue = useCallback(
    (
      endpoint: string,
      method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH',
      data?: any
    ): string => {
      const id = offlineSync.addToQueue(endpoint, method, data);
      setSyncState(prev => ({
        ...prev,
        queueLength: offlineSync.getQueue().length
      }));
      return id;
    },
    []
  );

  /**
   * Manually trigger synchronization
   */
  const syncNow = useCallback(async () => {
    if (syncState.isOnline && syncState.status !== 'syncing') {
      return offlineSync.sync();
    }
  }, [syncState.isOnline, syncState.status]);

  /**
   * Clear the entire sync queue
   */
  const clearSyncQueue = useCallback(() => {
    offlineSync.clearQueue();
    setSyncState(prev => ({
      ...prev,
      queueLength: 0
    }));
  }, []);

  /**
   * Remove a specific item from the queue
   */
  const removeFromSyncQueue = useCallback((id: string): boolean => {
    const result = offlineSync.removeFromQueue(id);
    if (result) {
      setSyncState(prev => ({
        ...prev,
        queueLength: offlineSync.getQueue().length
      }));
    }
    return result;
  }, []);

  /**
   * Get all items currently in the queue
   */
  const getSyncQueue = useCallback(() => {
    return offlineSync.getQueue();
  }, []);

  return {
    syncState,
    addToSyncQueue,
    syncNow,
    clearSyncQueue,
    removeFromSyncQueue,
    getSyncQueue
  };
}