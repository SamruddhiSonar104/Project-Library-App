import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { queryClient } from "@/lib/queryClient";

interface User {
  id: number;
  username: string;
  fullName: string;
  email: string;
  role: string;
}

interface AuthData {
  username: string;
  password: string;
}

interface RegisterData extends AuthData {
  fullName: string;
  email: string;
  role?: string;
}

function useAuth() {
  const [location, navigate] = useLocation();

  const { data: session, isLoading: isSessionLoading } = useQuery<{ user: User } | null>({
    queryKey: ["/api/auth/session"],
    staleTime: 1000 * 60 * 5, // 5 minutes
    retry: false,
  });

  // Rest of the function remains unchanged

  const login = useMutation({
    mutationFn: async (data: AuthData) => {
      const res = await apiRequest("POST", "/api/auth/login", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/session"] });
      
      // Redirect based on user role
      const user = queryClient.getQueryData<{ user: User }>(["/api/auth/session"])?.user;
      if (user?.role === "admin") {
        navigate("/admin-dashboard");
      } else {
        navigate("/student-dashboard");
      }
    }
  });
  
  const register = useMutation({
    mutationFn: async (data: RegisterData) => {
      const res = await apiRequest("POST", "/api/auth/register", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/session"] });
      
      // Redirect based on user role
      const user = queryClient.getQueryData<{ user: User }>(["/api/auth/session"])?.user;
      if (user?.role === "admin") {
        navigate("/admin-dashboard");
      } else {
        navigate("/student-dashboard");
      }
    }
  });
  
  const logout = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/auth/logout", {});
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/session"] });
      navigate("/login");
    }
  });

  return {
    user: session?.user,
    isAuthenticated: !!session?.user,
    isLoading: isSessionLoading,
    login,
    register,
    logout,
  };
}

// Export as both named and default export for compatibility
export { useAuth };
export default useAuth;
