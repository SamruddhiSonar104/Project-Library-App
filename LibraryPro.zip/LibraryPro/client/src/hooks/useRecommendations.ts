import { useQuery } from '@tanstack/react-query';
import { Book } from '@shared/schema';
import { getQueryFn } from '@/lib/queryClient';

/**
 * Interface for recommendation options
 */
export interface RecommendationOptions {
  genre?: string;
  readLevel?: 'easy' | 'medium' | 'advanced';
  limit?: number;
  similarToBookId?: number;
}

/**
 * Interface for recommendation results
 */
export interface RecommendationResult {
  books: Book[];
  message: string;
}

/**
 * Hook to fetch book recommendations
 * For non-personalized recommendations that don't require authentication
 */
export function useRecommendations(options: RecommendationOptions = {}) {
  const { genre, readLevel, limit, similarToBookId } = options;
  
  // Build query parameters
  const queryParams = new URLSearchParams();
  if (genre) queryParams.append('genre', genre);
  if (readLevel) queryParams.append('readLevel', readLevel);
  if (limit) queryParams.append('limit', limit.toString());
  if (similarToBookId) queryParams.append('similarToBookId', similarToBookId.toString());
  
  const queryString = queryParams.toString() ? `?${queryParams.toString()}` : '';
  
  return useQuery<RecommendationResult>({
    queryKey: ['/api/recommendations', genre, readLevel, limit, similarToBookId],
    queryFn: getQueryFn({ on401: 'returnNull' }),
    enabled: true
  });
}

/**
 * Hook to fetch personalized recommendations
 * These require authentication
 */
export function usePersonalRecommendations(options: Omit<RecommendationOptions, 'similarToBookId'> = {}) {
  const { genre, readLevel, limit } = options;
  
  // Build query parameters
  const queryParams = new URLSearchParams();
  if (genre) queryParams.append('genre', genre);
  if (readLevel) queryParams.append('readLevel', readLevel);
  if (limit) queryParams.append('limit', limit.toString());
  
  const queryString = queryParams.toString() ? `?${queryParams.toString()}` : '';
  
  return useQuery<RecommendationResult>({
    queryKey: ['/api/recommendations/personal', genre, readLevel, limit],
    queryFn: getQueryFn({ on401: 'returnNull' }),
    // This will fail if the user isn't authenticated, but the error will be handled
    enabled: true
  });
}