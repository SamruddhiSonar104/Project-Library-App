/**
 * Library management system offline synchronization module
 * Provides functionality to queue operations while offline and synchronize when online
 */

type SyncItem = {
  id: string;
  endpoint: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  data?: any;
  createdAt: number;
  attempts: number;
};

type SyncStatus = 'idle' | 'syncing' | 'success' | 'error';

class OfflineSyncManager {
  private static readonly STORAGE_KEY = 'library_offline_sync_queue';
  private static readonly MAX_RETRY_ATTEMPTS = 3;
  private queue: SyncItem[] = [];
  private isOnline: boolean = navigator.onLine;
  private isSyncing: boolean = false;
  private status: SyncStatus = 'idle';
  private listeners: Array<(status: SyncStatus, message?: string) => void> = [];

  constructor() {
    // Load saved queue from localStorage
    this.loadQueue();
    
    // Set up online/offline listeners
    window.addEventListener('online', this.handleOnline);
    window.addEventListener('offline', this.handleOffline);
    
    // Check connection status immediately
    this.isOnline = navigator.onLine;
    if (this.isOnline && this.queue.length > 0) {
      this.syncQueue();
    }
  }

  /**
   * Add an operation to the offline sync queue
   */
  public addToQueue(
    endpoint: string,
    method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH',
    data?: any
  ): string {
    // Generate a unique ID for this operation
    const id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const queueItem: SyncItem = {
      id,
      endpoint,
      method,
      data,
      createdAt: Date.now(),
      attempts: 0
    };
    
    // Add to queue
    this.queue.push(queueItem);
    this.saveQueue();
    
    // If we're online, try to sync immediately
    if (this.isOnline && !this.isSyncing) {
      this.syncQueue();
    }
    
    return id;
  }

  /**
   * Get the current sync status
   */
  public getStatus(): { status: SyncStatus; queueLength: number } {
    return {
      status: this.status,
      queueLength: this.queue.length
    };
  }

  /**
   * Subscribe to sync status changes
   */
  public subscribe(callback: (status: SyncStatus, message?: string) => void): () => void {
    this.listeners.push(callback);
    
    // Return unsubscribe function
    return () => {
      this.listeners = this.listeners.filter(listener => listener !== callback);
    };
  }

  /**
   * Manually trigger synchronization
   */
  public sync(): Promise<void> {
    if (this.isOnline && !this.isSyncing && this.queue.length > 0) {
      return this.syncQueue();
    }
    return Promise.resolve();
  }

  /**
   * Clear the entire sync queue
   */
  public clearQueue(): void {
    this.queue = [];
    this.saveQueue();
    this.notifyListeners('idle', 'Queue cleared');
  }

  /**
   * Remove a specific item from the queue
   */
  public removeFromQueue(id: string): boolean {
    const initialLength = this.queue.length;
    this.queue = this.queue.filter(item => item.id !== id);
    
    if (initialLength !== this.queue.length) {
      this.saveQueue();
      return true;
    }
    
    return false;
  }

  /**
   * Get all items currently in the queue
   */
  public getQueue(): SyncItem[] {
    return [...this.queue];
  }

  /**
   * Clean up event listeners
   */
  public destroy(): void {
    window.removeEventListener('online', this.handleOnline);
    window.removeEventListener('offline', this.handleOffline);
  }

  // Private methods
  
  private handleOnline = (): void => {
    this.isOnline = true;
    if (this.queue.length > 0) {
      this.syncQueue();
    }
  };

  private handleOffline = (): void => {
    this.isOnline = false;
    this.notifyListeners('idle', 'Device is offline');
  };

  private async syncQueue(): Promise<void> {
    if (this.isSyncing || !this.isOnline || this.queue.length === 0) {
      return;
    }
    
    this.isSyncing = true;
    this.status = 'syncing';
    this.notifyListeners('syncing', `Syncing ${this.queue.length} items`);
    
    let hasErrors = false;
    
    // Process queue items one by one
    const newQueue: SyncItem[] = [];
    
    for (const item of this.queue) {
      try {
        // Attempt to sync this item
        await this.syncItem(item);
      } catch (error) {
        hasErrors = true;
        
        // Increment attempts and keep in queue if under max retries
        const updatedItem = { ...item, attempts: item.attempts + 1 };
        
        if (updatedItem.attempts < OfflineSyncManager.MAX_RETRY_ATTEMPTS) {
          newQueue.push(updatedItem);
        }
      }
    }
    
    // Update queue with remaining items
    this.queue = newQueue;
    this.saveQueue();
    
    this.isSyncing = false;
    this.status = hasErrors ? 'error' : 'success';
    
    this.notifyListeners(
      this.status,
      hasErrors
        ? `Sync completed with errors. ${newQueue.length} items remaining.`
        : 'Sync completed successfully'
    );
  }

  private async syncItem(item: SyncItem): Promise<void> {
    const { endpoint, method, data } = item;
    
    const response = await fetch(endpoint, {
      method,
      headers: {
        'Content-Type': 'application/json'
      },
      body: data ? JSON.stringify(data) : undefined
    });
    
    if (!response.ok) {
      throw new Error(`Failed to sync item: ${response.status} ${response.statusText}`);
    }
  }

  private loadQueue(): void {
    try {
      const savedQueue = localStorage.getItem(OfflineSyncManager.STORAGE_KEY);
      if (savedQueue) {
        this.queue = JSON.parse(savedQueue);
      }
    } catch (error) {
      console.error('Failed to load offline sync queue:', error);
      this.queue = [];
    }
  }

  private saveQueue(): void {
    try {
      localStorage.setItem(OfflineSyncManager.STORAGE_KEY, JSON.stringify(this.queue));
    } catch (error) {
      console.error('Failed to save offline sync queue:', error);
    }
  }

  private notifyListeners(status: SyncStatus, message?: string): void {
    this.listeners.forEach(listener => listener(status, message));
  }
}

// Create a singleton instance
const offlineSync = new OfflineSyncManager();

export default offlineSync;