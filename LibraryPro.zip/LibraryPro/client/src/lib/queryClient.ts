import { QueryClient, QueryFunction } from "@tanstack/react-query";
import offlineSync from './offlineSync';

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
  offlineOptions?: {
    enableOfflineMode?: boolean;
    offlineKey?: string;
    optimisticData?: any;
  }
): Promise<Response> {
  // Check if we're online
  const isOnline = navigator.onLine;
  
  // If offline mode is enabled and we're offline, add to the sync queue
  if (!isOnline && offlineOptions?.enableOfflineMode) {
    // Add to the offline sync queue
    const syncId = offlineSync.addToQueue(url, method as any, data);
    
    // Return a fake response with the sync ID
    const mockResponse = new Response(
      JSON.stringify({
        success: true,
        message: 'Operation queued for synchronization',
        syncId,
        offline: true,
        ...(offlineOptions.optimisticData || {})
      }),
      {
        status: 202,
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );
    
    // Add a custom property to identify this as an offline response
    Object.defineProperty(mockResponse, 'isOfflineResponse', {
      value: true,
      writable: false
    });
    
    // Add the sync ID to identify this operation later
    Object.defineProperty(mockResponse, 'syncId', {
      value: syncId,
      writable: false
    });
    
    return mockResponse;
  }
  
  // Normal online flow
  const res = await fetch(url, {
    method,
    headers: data ? { "Content-Type": "application/json" } : {},
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include",
  });

  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
