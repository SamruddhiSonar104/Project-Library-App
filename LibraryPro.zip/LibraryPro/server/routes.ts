import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { getBookRecommendations } from "./services/recommendation";
import session from "express-session";
import MemoryStore from "memorystore";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { insertUserSchema, insertBookSchema, insertBorrowSchema, insertReservationSchema, insertLibraryCardSchema } from "@shared/schema";
import { z } from "zod";
import { add } from "date-fns";

const SessionStore = MemoryStore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure session middleware
  app.use(
    session({
      secret: "library-management-secret-key",
      resave: false,
      saveUninitialized: false,
      cookie: { maxAge: 24 * 60 * 60 * 1000 }, // 24 hours
      store: new SessionStore({
        checkPeriod: 86400000, // 24h
      }),
    })
  );

  // Configure passport middleware
  app.use(passport.initialize());
  app.use(passport.session());

  // Configure passport local strategy
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Incorrect username." });
        }
        if (user.password !== password) {
          return done(null, false, { message: "Incorrect password." });
        }
        return done(null, user);
      } catch (err) {
        return done(err);
      }
    })
  );

  // Configure passport serialization
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // Authentication middleware
  const isAuthenticated = (req: Request, res: Response, next: Function) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  const isAdmin = (req: Request, res: Response, next: Function) => {
    if (req.isAuthenticated() && (req.user as any)?.role === "admin") {
      return next();
    }
    res.status(403).json({ message: "Forbidden" });
  };

  // Authentication routes
  app.post("/api/auth/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).json({ message: info.message });
      }
      req.logIn(user, (err) => {
        if (err) {
          return next(err);
        }
        return res.status(200).json({ user });
      });
    })(req, res, next);
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username is taken
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already taken" });
      }
      
      const user = await storage.createUser(userData);
      
      // Auto-login after registration
      req.logIn(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Error logging in after registration" });
        }
        return res.status(201).json({ user });
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: err.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/auth/session", (req, res) => {
    if (req.isAuthenticated()) {
      return res.status(200).json({ user: req.user });
    }
    res.status(401).json({ message: "Not authenticated" });
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout(err => {
      if (err) {
        return res.status(500).json({ message: "Error during logout" });
      }
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  // Book routes
  app.get("/api/books", async (req, res) => {
    try {
      let books;
      if (req.query.search || req.query.category) {
        const searchQuery = req.query.search as string || "";
        const category = req.query.category as string;
        books = await storage.searchBooks(searchQuery, category);
      } else {
        books = await storage.getAllBooks();
      }
      res.status(200).json(books);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Get book by ISBN - this must come BEFORE the generic ID route
  app.get("/api/books/isbn/:isbn", async (req, res) => {
    try {
      const isbn = req.params.isbn;
      const book = await storage.getBookByISBN(isbn);
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      res.status(200).json(book);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Get book by ID
  app.get("/api/books/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const book = await storage.getBook(id);
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      res.status(200).json(book);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/books", isAdmin, async (req, res) => {
    try {
      const bookData = insertBookSchema.parse(req.body);
      
      // Check if ISBN is already in use
      const existingBook = await storage.getBookByISBN(bookData.isbn);
      if (existingBook) {
        return res.status(400).json({ message: "ISBN already exists" });
      }
      
      const book = await storage.createBook(bookData);
      res.status(201).json(book);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid book data", errors: err.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.put("/api/books/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const bookData = req.body;
      
      // Check if book exists
      const existingBook = await storage.getBook(id);
      if (!existingBook) {
        return res.status(404).json({ message: "Book not found" });
      }
      
      const book = await storage.updateBook(id, bookData);
      res.status(200).json(book);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/books/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Check if book exists
      const existingBook = await storage.getBook(id);
      if (!existingBook) {
        return res.status(404).json({ message: "Book not found" });
      }
      
      await storage.deleteBook(id);
      res.status(200).json({ message: "Book deleted successfully" });
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Borrow routes
  app.get("/api/borrows", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      let borrows;
      
      // Filter by bookId if provided
      if (req.query.bookId) {
        const bookId = parseInt(req.query.bookId as string);
        
        // Get all borrows for this book, only admins can see all borrows
        if (user.role === 'admin') {
          // Need to implement a method in storage to get borrows by book
          borrows = await storage.getAllBorrows();
          borrows = borrows.filter(borrow => borrow.bookId === bookId);
        } else {
          // Students can only see their own borrows
          borrows = await storage.getBorrowsByUser(user.id);
          borrows = borrows.filter(borrow => borrow.bookId === bookId);
        }
      } else {
        // No bookId filter, get all borrows based on role
        if (user.role === "admin") {
          borrows = await storage.getAllBorrows();
        } else {
          borrows = await storage.getBorrowsByUser(user.id);
        }
      }
      
      // Fetch book details for each borrow
      const borrowsWithDetails = await Promise.all(
        borrows.map(async (borrow) => {
          const book = await storage.getBook(borrow.bookId);
          return { ...borrow, book };
        })
      );
      
      res.status(200).json(borrowsWithDetails);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/borrows", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      
      // Set the user ID from the authenticated user
      const borrowData = {
        ...req.body,
        userId: user.id,
        dueDate: add(new Date(), { days: 30 }) // 30 days from now
      };
      
      const parsedData = insertBorrowSchema.parse(borrowData);
      
      // Check if book exists and is available
      const book = await storage.getBook(parsedData.bookId);
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      
      if (book.availableCopies <= 0) {
        return res.status(400).json({ message: "Book not available for borrowing" });
      }
      
      const borrow = await storage.createBorrow(parsedData);
      res.status(201).json(borrow);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid borrow data", errors: err.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/borrows/:id/return", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = req.user as any;
      
      // Get the borrow record
      const borrow = await storage.getBorrow(id);
      if (!borrow) {
        return res.status(404).json({ message: "Borrow record not found" });
      }
      
      // Check if the user is the borrower or an admin
      if (borrow.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const updatedBorrow = await storage.returnBook(id);
      res.status(200).json(updatedBorrow);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Reservation routes
  app.get("/api/reservations", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      let reservations;
      
      // Admin can see all reservations, students only see their own
      if (user.role === "admin") {
        reservations = await storage.getAllReservations();
      } else {
        reservations = await storage.getReservationsByUser(user.id);
      }
      
      // Fetch book details for each reservation
      const reservationsWithDetails = await Promise.all(
        reservations.map(async (reservation) => {
          const book = await storage.getBook(reservation.bookId);
          return { ...reservation, book };
        })
      );
      
      res.status(200).json(reservationsWithDetails);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/reservations", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      
      // Set the user ID from the authenticated user
      const reservationData = {
        ...req.body,
        userId: user.id
      };
      
      const parsedData = insertReservationSchema.parse(reservationData);
      
      // Check if book exists
      const book = await storage.getBook(parsedData.bookId);
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      
      const reservation = await storage.createReservation(parsedData);
      res.status(201).json(reservation);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid reservation data", errors: err.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.put("/api/reservations/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const reservationData = req.body;
      
      // Check if reservation exists
      const existingReservation = await storage.getReservation(id);
      if (!existingReservation) {
        return res.status(404).json({ message: "Reservation not found" });
      }
      
      const reservation = await storage.updateReservation(id, reservationData);
      res.status(200).json(reservation);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // User routes
  app.get("/api/users", isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.status(200).json(users);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  app.get("/api/users/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Only admins can view other users' details
      const currentUser = req.user as any;
      if (user.id !== currentUser.id && currentUser.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      res.status(200).json(user);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.put("/api/users/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userData = req.body;
      
      // Check if user exists
      const existingUser = await storage.getUser(id);
      if (!existingUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const user = await storage.updateUser(id, userData);
      res.status(200).json(user);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/users/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Check if user exists
      const existingUser = await storage.getUser(id);
      if (!existingUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      await storage.deleteUser(id);
      res.status(200).json({ message: "User deleted successfully" });
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Book recommendation routes
  // Library Card routes
  app.get("/api/library-cards", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      let cards;
      
      if (user.role === "admin") {
        // Admin can see all library cards
        cards = await storage.getAllLibraryCards();
      } else {
        // Regular users can only see their own library card
        const card = await storage.getLibraryCardByUserId(user.id);
        cards = card ? [card] : [];
      }
      
      res.status(200).json(cards);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  app.get("/api/library-cards/my-card", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const card = await storage.getLibraryCardByUserId(user.id);
      
      if (!card) {
        return res.status(404).json({ message: "Library card not found" });
      }
      
      res.status(200).json(card);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  app.post("/api/library-cards", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      
      // Check if user already has a library card
      const existingCard = await storage.getLibraryCardByUserId(user.id);
      if (existingCard) {
        return res.status(400).json({ message: "User already has a library card" });
      }
      
      // Use current date + 1 year as default expiry
      const oneYearFromNow = add(new Date(), { years: 1 });
      
      // Prepare library card data
      const cardData = {
        userId: user.id,
        ...req.body,
        expiryDate: req.body.expiryDate || oneYearFromNow
      };
      
      const parsedData = insertLibraryCardSchema.parse(cardData);
      const card = await storage.createLibraryCard(parsedData);
      
      res.status(201).json(card);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid library card data", errors: err.errors });
      }
      if (err instanceof Error) {
        return res.status(400).json({ message: err.message });
      }
      res.status(500).json({ message: "Server error" });
    }
  });
  
  app.put("/api/library-cards/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = req.user as any;
      
      // Get the existing card
      const card = await storage.getLibraryCard(id);
      if (!card) {
        return res.status(404).json({ message: "Library card not found" });
      }
      
      // Check if user is the card owner or an admin
      if (card.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      // Update the card
      const updatedCard = await storage.updateLibraryCard(id, req.body);
      res.status(200).json(updatedCard);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid library card data", errors: err.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Admin endpoint to renew a library card
  app.post("/api/library-cards/:id/renew", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Get the existing card
      const card = await storage.getLibraryCard(id);
      if (!card) {
        return res.status(404).json({ message: "Library card not found" });
      }
      
      // Calculate new expiry date (1 year from current expiry or today)
      const currentExpiry = new Date(card.expiryDate);
      const today = new Date();
      const baseDate = currentExpiry > today ? currentExpiry : today;
      const newExpiryDate = add(baseDate, { years: 1 });
      
      // Update the card with new expiry date and active status
      const updatedCard = await storage.updateLibraryCard(id, {
        expiryDate: newExpiryDate,
        status: "active"
      });
      
      res.status(200).json(updatedCard);
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Scan or retrieve card by card number
  app.get("/api/library-cards/scan/:cardNumber", isAuthenticated, async (req, res) => {
    try {
      const { cardNumber } = req.params;
      const user = req.user as any;
      
      // Only admin can scan cards
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const card = await storage.getLibraryCardByCardNumber(cardNumber);
      if (!card) {
        return res.status(404).json({ message: "Library card not found" });
      }
      
      // Fetch user details
      const cardOwner = await storage.getUser(card.userId);
      if (!cardOwner) {
        return res.status(404).json({ message: "Card owner not found" });
      }
      
      res.status(200).json({
        card,
        user: cardOwner
      });
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Recommendation routes
  app.get("/api/recommendations", async (req, res) => {
    try {
      const options = {
        userId: req.query.userId ? parseInt(req.query.userId as string) : undefined,
        genre: req.query.genre as string,
        readLevel: req.query.readLevel as 'easy' | 'medium' | 'advanced',
        limit: req.query.limit ? parseInt(req.query.limit as string) : 5,
        similarToBookId: req.query.similarToBookId ? parseInt(req.query.similarToBookId as string) : undefined
      };
      
      const recommendations = await getBookRecommendations(options);
      res.status(200).json(recommendations);
    } catch (err) {
      res.status(500).json({ message: "Server error getting recommendations" });
    }
  });
  
  // For personalized recommendations (requires authentication)
  app.get("/api/recommendations/personal", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const options = {
        userId: user.id,
        genre: req.query.genre as string,
        limit: req.query.limit ? parseInt(req.query.limit as string) : 5
      };
      
      const recommendations = await getBookRecommendations(options);
      res.status(200).json(recommendations);
    } catch (err) {
      res.status(500).json({ message: "Server error getting personalized recommendations" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
