import { db } from './db';
import { users, books } from '@shared/schema';
import { storage } from './storage';

async function initDatabase() {
  try {
    console.log('Initializing database with sample data...');
    
    // Check if users exist
    const existingUsers = await db.select().from(users);
    if (existingUsers.length === 0) {
      console.log('Adding sample users...');
      
      // Add admin user
      await storage.createUser({
        username: "admin",
        password: "admin123",
        fullName: "Admin User",
        email: "admin@library.com",
        role: "admin"
      });
      
      // Add student user
      await storage.createUser({
        username: "student",
        password: "student123",
        fullName: "Sarah Johnson",
        email: "sarah@example.com",
        role: "student"
      });
      
      console.log('Sample users added successfully!');
    } else {
      console.log('Users already exist, skipping user creation.');
    }
    
    // Check if books exist
    const existingBooks = await db.select().from(books);
    if (existingBooks.length === 0) {
      console.log('Adding sample books...');
      
      // Add sample books
      await storage.createBook({
        title: "The Great Gatsby",
        author: "F. Scott Fitzgerald",
        isbn: "9780743273565",
        category: "Fiction",
        description: "A classic novel about the American Dream set in the Roaring Twenties.",
        coverImage: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?q=80&w=1000&auto=format",
        totalCopies: 5,
        availableCopies: 3
      });
      
      await storage.createBook({
        title: "To Kill a Mockingbird",
        author: "Harper Lee",
        isbn: "9780061120084",
        category: "Fiction",
        description: "A novel about racial inequality and moral growth in the American South.",
        coverImage: "https://images.unsplash.com/photo-1589998059171-988d887df646?q=80&w=1000&auto=format",
        totalCopies: 3,
        availableCopies: 1
      });
      
      await storage.createBook({
        title: "1984",
        author: "George Orwell",
        isbn: "9780451524935",
        category: "Science Fiction",
        description: "A dystopian social science fiction novel and cautionary tale.",
        coverImage: "https://images.unsplash.com/photo-1541963463532-d68292c34b19?q=80&w=1000&auto=format",
        totalCopies: 2,
        availableCopies: 0
      });
      
      console.log('Sample books added successfully!');
    } else {
      console.log('Books already exist, skipping book creation.');
    }
    
    console.log('Database initialization completed!');
  } catch (error) {
    console.error('Error initializing database:', error);
  }
}

export { initDatabase };