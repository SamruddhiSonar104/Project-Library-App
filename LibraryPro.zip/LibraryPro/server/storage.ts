import { 
  users, type User, type InsertUser,
  books, type Book, type InsertBook,
  borrows, type Borrow, type InsertBorrow,
  reservations, type Reservation, type InsertReservation,
  libraryCards, type LibraryCard, type InsertLibraryCard
} from "@shared/schema";
import { add } from "date-fns";
import { db } from "./db";
import { eq, like, or, and, desc, asc, isNull } from "drizzle-orm";

// Storage interface for the library management system
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getAllUsers(): Promise<User[]>;
  
  // Book operations
  getBook(id: number): Promise<Book | undefined>;
  getBookByISBN(isbn: string): Promise<Book | undefined>;
  createBook(book: InsertBook): Promise<Book>;
  updateBook(id: number, book: Partial<InsertBook>): Promise<Book | undefined>;
  deleteBook(id: number): Promise<boolean>;
  getAllBooks(): Promise<Book[]>;
  searchBooks(query: string, category?: string): Promise<Book[]>;
  
  // Borrow operations
  getBorrow(id: number): Promise<Borrow | undefined>;
  createBorrow(borrow: InsertBorrow): Promise<Borrow>;
  updateBorrow(id: number, borrow: Partial<InsertBorrow>): Promise<Borrow | undefined>;
  returnBook(id: number): Promise<Borrow | undefined>;
  getBorrowsByUser(userId: number): Promise<Borrow[]>;
  getAllBorrows(): Promise<Borrow[]>;
  
  // Reservation operations
  getReservation(id: number): Promise<Reservation | undefined>;
  createReservation(reservation: InsertReservation): Promise<Reservation>;
  updateReservation(id: number, reservation: Partial<Reservation>): Promise<Reservation | undefined>;
  getReservationsByUser(userId: number): Promise<Reservation[]>;
  getAllReservations(): Promise<Reservation[]>;
  
  // Library Card operations
  getLibraryCard(id: number): Promise<LibraryCard | undefined>;
  getLibraryCardByUserId(userId: number): Promise<LibraryCard | undefined>;
  getLibraryCardByCardNumber(cardNumber: string): Promise<LibraryCard | undefined>;
  createLibraryCard(libraryCard: InsertLibraryCard): Promise<LibraryCard>;
  updateLibraryCard(id: number, libraryCard: Partial<InsertLibraryCard>): Promise<LibraryCard | undefined>;
  getAllLibraryCards(): Promise<LibraryCard[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const users = await db.select().from(this.users).where(eq(this.users.id, id));
    return users.length > 0 ? users[0] : undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const users = await db.select().from(this.users).where(eq(this.users.username, username));
    return users.length > 0 ? users[0] : undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    const inserted = await db.insert(this.users).values(user).returning();
    return inserted[0];
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const updated = await db
      .update(this.users)
      .set(userData)
      .where(eq(this.users.id, id))
      .returning();
    
    return updated.length > 0 ? updated[0] : undefined;
  }

  async deleteUser(id: number): Promise<boolean> {
    const deleted = await db
      .delete(this.users)
      .where(eq(this.users.id, id))
      .returning({ id: this.users.id });
    
    return deleted.length > 0;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(this.users);
  }

  // Book operations
  async getBook(id: number): Promise<Book | undefined> {
    const books = await db.select().from(this.books).where(eq(this.books.id, id));
    return books.length > 0 ? books[0] : undefined;
  }

  async getBookByISBN(isbn: string): Promise<Book | undefined> {
    const books = await db.select().from(this.books).where(eq(this.books.isbn, isbn));
    return books.length > 0 ? books[0] : undefined;
  }

  async createBook(book: InsertBook): Promise<Book> {
    const inserted = await db.insert(this.books).values(book).returning();
    return inserted[0];
  }

  async updateBook(id: number, bookData: Partial<InsertBook>): Promise<Book | undefined> {
    const updated = await db
      .update(this.books)
      .set(bookData)
      .where(eq(this.books.id, id))
      .returning();
    
    return updated.length > 0 ? updated[0] : undefined;
  }

  async deleteBook(id: number): Promise<boolean> {
    const deleted = await db
      .delete(this.books)
      .where(eq(this.books.id, id))
      .returning({ id: this.books.id });
    
    return deleted.length > 0;
  }

  async getAllBooks(): Promise<Book[]> {
    return await db.select().from(this.books);
  }

  async searchBooks(query: string, category?: string): Promise<Book[]> {
    let whereClause = or(
      like(this.books.title, `%${query}%`),
      like(this.books.author, `%${query}%`),
      like(this.books.isbn, `%${query}%`)
    );
    
    if (category && category !== 'All Categories') {
      whereClause = and(
        whereClause,
        eq(this.books.category, category)
      );
    }
    
    return await db.select().from(this.books).where(whereClause);
  }

  // Borrow operations
  async getBorrow(id: number): Promise<Borrow | undefined> {
    const borrows = await db.select().from(this.borrows).where(eq(this.borrows.id, id));
    return borrows.length > 0 ? borrows[0] : undefined;
  }

  async createBorrow(borrow: InsertBorrow): Promise<Borrow> {
    // Start a transaction to handle both borrow creation and book update
    const borrowResult = await db.transaction(async (tx) => {
      // First, check if the book is available
      const book = await tx
        .select()
        .from(this.books)
        .where(eq(this.books.id, borrow.bookId));
      
      if (book.length === 0 || book[0].availableCopies <= 0) {
        throw new Error('Book not available for borrowing');
      }
      
      // Create the borrow entry
      const newBorrow = await tx
        .insert(this.borrows)
        .values({
          ...borrow,
          status: "active",
          borrowDate: new Date()
        })
        .returning();
      
      // Update the book's available copies
      await tx
        .update(this.books)
        .set({ availableCopies: book[0].availableCopies - 1 })
        .where(eq(this.books.id, borrow.bookId));
      
      return newBorrow[0];
    });
    
    return borrowResult;
  }

  async updateBorrow(id: number, borrowData: Partial<InsertBorrow>): Promise<Borrow | undefined> {
    const updated = await db
      .update(this.borrows)
      .set(borrowData)
      .where(eq(this.borrows.id, id))
      .returning();
    
    return updated.length > 0 ? updated[0] : undefined;
  }

  async returnBook(id: number): Promise<Borrow | undefined> {
    // Start a transaction to handle both borrow update and book update
    const returnResult = await db.transaction(async (tx) => {
      // Get the borrow record
      const borrowRecords = await tx
        .select()
        .from(this.borrows)
        .where(and(
          eq(this.borrows.id, id),
          eq(this.borrows.status, "active")
        ));
      
      if (borrowRecords.length === 0) {
        return undefined;
      }
      
      const borrow = borrowRecords[0];
      
      // Update the borrow status
      const updatedBorrow = await tx
        .update(this.borrows)
        .set({
          status: "returned",
          returnDate: new Date()
        })
        .where(eq(this.borrows.id, id))
        .returning();
      
      // Get the book and update its available copies
      const bookRecords = await tx
        .select()
        .from(this.books)
        .where(eq(this.books.id, borrow.bookId));
      
      if (bookRecords.length > 0) {
        await tx
          .update(this.books)
          .set({
            availableCopies: bookRecords[0].availableCopies + 1
          })
          .where(eq(this.books.id, borrow.bookId));
      }
      
      return updatedBorrow[0];
    });
    
    return returnResult;
  }

  async getBorrowsByUser(userId: number): Promise<Borrow[]> {
    return await db
      .select()
      .from(this.borrows)
      .where(eq(this.borrows.userId, userId));
  }

  async getAllBorrows(): Promise<Borrow[]> {
    return await db.select().from(this.borrows);
  }

  // Reservation operations
  async getReservation(id: number): Promise<Reservation | undefined> {
    const reservations = await db
      .select()
      .from(this.reservations)
      .where(eq(this.reservations.id, id));
    
    return reservations.length > 0 ? reservations[0] : undefined;
  }

  async createReservation(reservation: InsertReservation): Promise<Reservation> {
    const inserted = await db
      .insert(this.reservations)
      .values({
        ...reservation,
        status: "pending",
        reservationDate: new Date()
      })
      .returning();
    
    return inserted[0];
  }

  async updateReservation(id: number, reservationData: Partial<Reservation>): Promise<Reservation | undefined> {
    const updated = await db
      .update(this.reservations)
      .set(reservationData)
      .where(eq(this.reservations.id, id))
      .returning();
    
    return updated.length > 0 ? updated[0] : undefined;
  }

  async getReservationsByUser(userId: number): Promise<Reservation[]> {
    return await db
      .select()
      .from(this.reservations)
      .where(eq(this.reservations.userId, userId));
  }

  async getAllReservations(): Promise<Reservation[]> {
    return await db.select().from(this.reservations);
  }

  // Library Card operations
  async getLibraryCard(id: number): Promise<LibraryCard | undefined> {
    const cards = await db
      .select()
      .from(this.libraryCards)
      .where(eq(this.libraryCards.id, id));
    
    return cards.length > 0 ? cards[0] : undefined;
  }

  async getLibraryCardByUserId(userId: number): Promise<LibraryCard | undefined> {
    const cards = await db
      .select()
      .from(this.libraryCards)
      .where(eq(this.libraryCards.userId, userId));
    
    return cards.length > 0 ? cards[0] : undefined;
  }

  async getLibraryCardByCardNumber(cardNumber: string): Promise<LibraryCard | undefined> {
    const cards = await db
      .select()
      .from(this.libraryCards)
      .where(eq(this.libraryCards.cardNumber, cardNumber));
    
    return cards.length > 0 ? cards[0] : undefined;
  }

  async createLibraryCard(libraryCard: InsertLibraryCard): Promise<LibraryCard> {
    // Check if user already has a card
    const existingCard = await this.getLibraryCardByUserId(libraryCard.userId);
    if (existingCard) {
      throw new Error('User already has a library card');
    }
    
    // Generate card number if not provided
    if (!libraryCard.cardNumber) {
      libraryCard = {
        ...libraryCard,
        cardNumber: this.generateCardNumber(),
      };
    }
    
    const inserted = await db
      .insert(this.libraryCards)
      .values({
        ...libraryCard,
        status: "active",
        issueDate: new Date()
      })
      .returning();
    
    return inserted[0];
  }

  async updateLibraryCard(id: number, cardData: Partial<InsertLibraryCard>): Promise<LibraryCard | undefined> {
    const updated = await db
      .update(this.libraryCards)
      .set(cardData)
      .where(eq(this.libraryCards.id, id))
      .returning();
    
    return updated.length > 0 ? updated[0] : undefined;
  }

  async getAllLibraryCards(): Promise<LibraryCard[]> {
    return await db.select().from(this.libraryCards);
  }

  // Helper method to generate a random library card number
  private generateCardNumber(): string {
    const prefix = "LIB";
    const timestamp = Date.now().toString().slice(-6);
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    return `${prefix}-${timestamp}-${random}`;
  }

  // Private properties for table access
  private get users() { return users; }
  private get books() { return books; }
  private get borrows() { return borrows; }
  private get reservations() { return reservations; }
  private get libraryCards() { return libraryCards; }
}

export const storage = new DatabaseStorage();
