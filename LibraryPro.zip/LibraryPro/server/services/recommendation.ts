/**
 * Book recommendation service using Perplexity API
 * For demo purposes only
 */

import { Book, User } from '@shared/schema';
import { storage } from '../storage';

// Interface for recommendation options
interface RecommendationOptions {
  userId?: number;
  genre?: string;
  readLevel?: 'easy' | 'medium' | 'advanced';
  limit?: number;
  similarToBookId?: number;
}

// Interface for recommendation results
interface RecommendationResult {
  books: Book[];
  message: string;
}

/**
 * Get book recommendations based on various criteria
 * This is a simplified demo implementation that doesn't use the actual API
 */
export async function getBookRecommendations(options: RecommendationOptions): Promise<RecommendationResult> {
  const { userId, genre, readLevel, limit = 5, similarToBookId } = options;
  
  try {
    let books: Book[] = [];
    let message = '';
    let prompt = '';
    
    // Try using Perplexity API first if available
    if (process.env.PERPLEXITY_API_KEY && process.env.PERPLEXITY_API_KEY.trim() !== '') {
      // Build the appropriate prompt based on the options
      if (similarToBookId) {
        const sourceBook = await storage.getBook(similarToBookId);
        if (sourceBook) {
          prompt = `Recommend ${limit} books similar to "${sourceBook.title}" by ${sourceBook.author}, which is in the ${sourceBook.category} category. Return your response as a JSON object with a 'message' string and a 'books' array.`;
        }
      } else if (userId) {
        const user = await storage.getUser(userId);
        const userBorrows = await storage.getBorrowsByUser(userId);
        
        if (user && userBorrows.length > 0) {
          // Get book details for what they've borrowed
          const borrowedBooks = await Promise.all(
            userBorrows.map(async borrow => await storage.getBook(borrow.bookId))
          );
          
          const validBooks = borrowedBooks.filter(book => book !== undefined) as Book[];
          
          if (validBooks.length > 0) {
            const bookTitles = validBooks.map(book => `"${book.title}" by ${book.author}`).join(", ");
            prompt = `User ${user.fullName} has previously borrowed these books: ${bookTitles}. ${genre ? `They are interested in the ${genre} genre.` : ''} ${readLevel ? `They prefer ${readLevel} reading level.` : ''} Based on this, recommend ${limit} books they might enjoy. Return your response as a JSON object with a 'message' string and a 'books' array.`;
          } else {
            prompt = `Recommend ${limit} popular books ${genre ? `in the ${genre} genre` : ''} ${readLevel ? `at ${readLevel} reading level` : ''}. Return your response as a JSON object with a 'message' string and a 'books' array.`;
          }
        } else if (user) {
          prompt = `Recommend ${limit} popular books for a new library user ${genre ? `in the ${genre} genre` : ''} ${readLevel ? `at ${readLevel} reading level` : ''}. Return your response as a JSON object with a 'message' string and a 'books' array.`;
        }
      } else {
        prompt = `Recommend ${limit} popular books ${genre ? `in the ${genre} genre` : ''} ${readLevel ? `at ${readLevel} reading level` : ''} that would be found in a typical library. Return your response as a JSON object with a 'message' string and a 'books' array.`;
      }
      
      // Call the Perplexity API if we have a valid prompt
      if (prompt) {
        const apiResult = await callPerplexityAPI(prompt);
        
        if (apiResult && apiResult.books && apiResult.books.length > 0) {
          // Map API results to our Book schema
          // We'll assign temporary IDs that won't conflict with our DB
          const tempIdStart = 10000;
          books = apiResult.books.map((book: any, index: number) => ({
            id: tempIdStart + index,
            title: book.title,
            author: book.author,
            isbn: book.isbn || `temp-isbn-${index}`,
            description: book.description || "No description available",
            coverImage: book.coverImage || "https://via.placeholder.com/150",
            category: book.category || genre || "Uncategorized",
            totalCopies: 1,
            availableCopies: book.available === undefined ? 1 : (book.available ? 1 : 0),
            publicationYear: book.publicationYear || new Date().getFullYear() - Math.floor(Math.random() * 30)
          }));
          
          message = apiResult.message || "Recommended books based on your preferences";
          
          return { books, message };
        }
      }
    }
    
    // Fallback to database if API call fails or is unavailable
    
    // If looking for similar books
    if (similarToBookId) {
      const sourceBook = await storage.getBook(similarToBookId);
      if (sourceBook) {
        const allBooks = await storage.getAllBooks();
        books = allBooks
          .filter(book => 
            book.id !== similarToBookId && 
            book.category === sourceBook.category
          )
          .slice(0, limit);
          
        message = `Books similar to "${sourceBook.title}" in the ${sourceBook.category} category`;
      }
    } 
    // If recommendations for a specific user
    else if (userId) {
      const user = await storage.getUser(userId);
      if (user) {
        const allBooks = await storage.getAllBooks();
        const userBorrows = await storage.getBorrowsByUser(userId);
        
        // Get books user hasn't borrowed yet
        const borrowedBookIds = userBorrows.map(borrow => borrow.bookId);
        books = allBooks
          .filter(book => 
            !borrowedBookIds.includes(book.id) &&
            (!genre || book.category === genre)
          )
          .slice(0, limit);
          
        message = `Personalized recommendations for ${user.fullName}`;
      }
    }
    // Otherwise, get books by genre or general recommendations
    else {
      const allBooks = await storage.getAllBooks();
      
      if (genre) {
        books = allBooks
          .filter(book => book.category === genre)
          .slice(0, limit);
        message = `Top recommendations in ${genre}`;
      } else {
        // Just return some books, sorted by most recent
        // Sort by book ID as a fallback since we don't have createdAt
        books = allBooks
          .sort((a, b) => b.id - a.id) // Use ID as a proxy for recency
          .slice(0, limit);
        message = 'Popular books currently trending';
      }
    }
    
    return {
      books,
      message
    };
  } catch (error) {
    console.error('Error getting recommendations:', error);
    return {
      books: [],
      message: 'Unable to generate recommendations at this time'
    };
  }
}

/**
 * Call Perplexity API to get intelligent book recommendations
 */
async function callPerplexityAPI(prompt: string): Promise<any> {
  // Check if API key is available and not empty
  if (!process.env.PERPLEXITY_API_KEY || process.env.PERPLEXITY_API_KEY.trim() === '') {
    console.warn("PERPLEXITY_API_KEY is not set or empty, using fallback method");
    // Use the existing database instead
    return null;
  }
  
  // Remove any newlines or other whitespace that might be causing issues
  const apiKey = process.env.PERPLEXITY_API_KEY.trim();

  try {
    const response = await fetch("https://api.perplexity.ai/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "llama-3.1-sonar-small-128k-online",
        messages: [
          {
            role: "system",
            content: "You are a library recommendation system assistant. Your task is to recommend books based on user preferences. Return your response as a JSON object with a message and a list of book recommendations. Include only books that are realistic and likely to exist in a typical library. Each book should have id, title, author, description, coverImage, category and availability status."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.2,
        top_p: 0.9,
        return_images: false,
        stream: false
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Perplexity API error: ${response.status} ${errorText}`);
    }

    const data = await response.json();
    
    try {
      // Extract JSON from the content
      const content = data.choices[0].message.content;
      const jsonMatch = content.match(/```json([\s\S]*?)```/) || content.match(/{[\s\S]*?}/);
      
      if (jsonMatch) {
        const jsonString = jsonMatch[1] ? jsonMatch[1].trim() : jsonMatch[0];
        const parsed = JSON.parse(jsonString);
        return parsed;
      } else {
        // Try to parse the whole content as JSON
        return JSON.parse(content);
      }
    } catch (parseError) {
      console.error("Failed to parse Perplexity API response as JSON:", parseError);
      return null;
    }
  } catch (error) {
    console.error("Error calling Perplexity API:", error);
    return null;
  }
}